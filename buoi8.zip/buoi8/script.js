/**
 * HỌC PHẦN 111101 · THIẾT KẾ WEB - ĐẠI HỌC LẠC HỒNG
 * BUỔI 8 - HOẠT ĐỘNG 2: "LOGIC BUILDER" - MÁY TÍNH MINI (TRANG 59)
 */

/* =========================================================================
   PHẦN 1: HƯỚNG DẪN CƠ BẢN - KIỂM TRA ĐẠT / CHƯA ĐẠT
   Yêu cầu: Nhập vào số điểm. Nếu điểm >= 5 thì hiện "Chúc mừng bạn đã đạt!",
   ngược lại hiện "Rất tiếc, hãy cố gắng hơn!".
   ========================================================================= */

// 1.1 Chạy trực tiếp bằng prompt() và alert() theo đúng giáo trình
function chayKiemTraDatPrompt() {
    let input = prompt("Nhập vào số điểm của bạn (thang điểm 10):");

    // Nếu người dùng bấm Cancel
    if (input === null) {
        return;
    }

    let diem = parseFloat(input.trim());

    // Kiểm tra tính hợp lệ của dữ liệu nhập
    if (isNaN(diem) || diem < 0 || diem > 10) {
        alert("Vui lòng nhập điểm số hợp lệ từ 0 đến 10!");
        return;
    }

    // Logic kiểm tra rẽ nhánh if - else
    if (diem >= 5) {
        alert("Chúc mừng bạn đã đạt! (Điểm: " + diem + ")");
    } else {
        alert("Rất tiếc, hãy cố gắng hơn! (Điểm: " + diem + ")");
    }
}

// 1.2 Hiển thị kết quả tương tác trực tiếp trên giao diện Web
function kiemTraDatWeb() {
    let inputVal = document.getElementById("input-diem-coban").value;
    let resultBox = document.getElementById("result-coban");
    let iconBox = document.getElementById("icon-coban");
    let textBox = document.getElementById("text-coban");

    if (inputVal === "") {
        hienThiKetQua(resultBox, iconBox, textBox, "warn", "⚠️", "Vui lòng nhập điểm trước khi kiểm tra!");
        return;
    }

    let diem = parseFloat(inputVal);

    if (isNaN(diem) || diem < 0 || diem > 10) {
        hienThiKetQua(resultBox, iconBox, textBox, "fail", "❌", "Điểm không hợp lệ! Vui lòng nhập số từ 0 đến 10.");
        return;
    }

    if (diem >= 5) {
        hienThiKetQua(resultBox, iconBox, textBox, "pass", "🎉", `<strong>Chúc mừng bạn đã đạt!</strong> (Điểm số: ${diem})`);
    } else {
        hienThiKetQua(resultBox, iconBox, textBox, "fail", "😢", `<strong>Rất tiếc, hãy cố gắng hơn!</strong> (Điểm số: ${diem})`);
    }
}


/* =========================================================================
   PHẦN 2: PROMPT MẪU - XẾP LOẠI HỌC LỰC CHI TIẾT
   Yêu cầu: Sử dụng prompt() để lấy điểm, sau đó dùng if-else để kiểm tra và
   alert() kết quả: Giỏi (>8), Khá (>6.5), Trung bình (>=5), Yếu (<5).
   ========================================================================= */

// 2.1 Chạy trực tiếp bằng prompt() và alert() theo Prompt mẫu
function chayXepLoaiPrompt() {
    let input = prompt("Nhập điểm số để xếp loại (thang điểm 10):");

    if (input === null) {
        return;
    }

    let diem = parseFloat(input.trim());

    if (isNaN(diem) || diem < 0 || diem > 10) {
        alert("Điểm không hợp lệ! Vui lòng nhập số từ 0 đến 10.");
        return;
    }

    let xepLoai = "";

    // Cấu trúc if - else if - else xếp loại
    if (diem > 8) {
        xepLoai = "Giỏi";
    } else if (diem > 6.5) {
        xepLoai = "Khá";
    } else if (diem >= 5) {
        xepLoai = "Trung bình";
    } else {
        xepLoai = "Yếu";
    }

    alert("Điểm số của bạn: " + diem + "\nKết quả xếp loại: " + xepLoai);
}

// 2.2 Hiển thị kết quả tương tác trực tiếp trên giao diện Web
function xepLoaiWeb() {
    let inputVal = document.getElementById("input-diem-xeploai").value;
    let resultBox = document.getElementById("result-xeploai");
    let iconBox = document.getElementById("icon-xeploai");
    let textBox = document.getElementById("text-xeploai");

    if (inputVal === "") {
        hienThiKetQua(resultBox, iconBox, textBox, "warn", "⚠️", "Vui lòng nhập điểm trước khi xếp loại!");
        return;
    }

    let diem = parseFloat(inputVal);

    if (isNaN(diem) || diem < 0 || diem > 10) {
        hienThiKetQua(resultBox, iconBox, textBox, "fail", "❌", "Điểm không hợp lệ! Vui lòng nhập số từ 0 đến 10.");
        return;
    }

    if (diem > 8) {
        hienThiKetQua(resultBox, iconBox, textBox, "pass", "🌟", `Điểm: <strong>${diem}</strong> &bull; Xếp loại: <strong style="color: #34d399">Giỏi</strong>`);
    } else if (diem > 6.5) {
        hienThiKetQua(resultBox, iconBox, textBox, "info", "✨", `Điểm: <strong>${diem}</strong> &bull; Xếp loại: <strong style="color: #c084fc">Khá</strong>`);
    } else if (diem >= 5) {
        hienThiKetQua(resultBox, iconBox, textBox, "warn", "👌", `Điểm: <strong>${diem}</strong> &bull; Xếp loại: <strong style="color: #fbbf24">Trung bình</strong>`);
    } else {
        hienThiKetQua(resultBox, iconBox, textBox, "fail", "📚", `Điểm: <strong>${diem}</strong> &bull; Xếp loại: <strong style="color: #f87171">Yếu</strong>`);
    }
}

// Hàm bổ trợ hiển thị hộp thông báo
function hienThiKetQua(box, iconEl, textEl, type, icon, msg) {
    box.className = `result-box ${type}`;
    iconEl.innerHTML = icon;
    textEl.innerHTML = msg;
    box.classList.remove("hidden");
}


/* =========================================================================
   PHẦN 3: MỞ RỘNG - MÁY TÍNH MINI (PROMPT & GIAO DIỆN)
   ========================================================================= */

// 3.1 Máy tính qua prompt() & alert()
function chayMayTinhPrompt() {
    let num1Input = prompt("Nhập số thứ nhất (a):");
    if (num1Input === null) return;
    let a = parseFloat(num1Input);
    if (isNaN(a)) {
        alert("Số thứ nhất không hợp lệ!");
        return;
    }

    let op = prompt("Nhập phép tính (+, -, *, /):");
    if (op === null) return;
    op = op.trim();
    if (!["+", "-", "*", "/"].includes(op)) {
        alert("Phép tính không hợp lệ! Chỉ chấp nhận +, -, *, /");
        return;
    }

    let num2Input = prompt("Nhập số thứ hai (b):");
    if (num2Input === null) return;
    let b = parseFloat(num2Input);
    if (isNaN(b)) {
        alert("Số thứ hai không hợp lệ!");
        return;
    }

    let ketQua;
    if (op === "+") {
        ketQua = a + b;
    } else if (op === "-") {
        ketQua = a - b;
    } else if (op === "*") {
        ketQua = a * b;
    } else if (op === "/") {
        if (b === 0) {
            alert("Lỗi: Không thể chia cho số 0!");
            return;
        }
        ketQua = a / b;
    }

    alert(`Kết quả phép tính:\n${a} ${op} ${b} = ${ketQua}`);
}


// 3.2 Logic màn hình máy tính bỏ túi Mini Calculator trên giao diện Web
let calcCurrent = "0";
let calcPrev = null;
let calcOperation = null;
let calcResetOnNext = false;

function updateCalcScreen() {
    const screen = document.getElementById("calc-screen");
    if (screen) {
        screen.innerText = calcCurrent;
    }
}

function calcNum(num) {
    if (calcCurrent === "0" || calcResetOnNext) {
        calcCurrent = num;
        calcResetOnNext = false;
    } else {
        if (calcCurrent.length < 12) {
            calcCurrent += num;
        }
    }
    updateCalcScreen();
}

function calcDot() {
    if (calcResetOnNext) {
        calcCurrent = "0.";
        calcResetOnNext = false;
    } else if (!calcCurrent.includes(".")) {
        calcCurrent += ".";
    }
    updateCalcScreen();
}

function calcClear() {
    calcCurrent = "0";
    calcPrev = null;
    calcOperation = null;
    calcResetOnNext = false;
    updateCalcScreen();
}

function calcDel() {
    if (calcCurrent.length > 1) {
        calcCurrent = calcCurrent.slice(0, -1);
    } else {
        calcCurrent = "0";
    }
    updateCalcScreen();
}

function calcPercent() {
    let val = parseFloat(calcCurrent);
    if (!isNaN(val)) {
        calcCurrent = (val / 100).toString();
        updateCalcScreen();
    }
}

function calcOp(op) {
    calcPrev = parseFloat(calcCurrent);
    calcOperation = op;
    calcResetOnNext = true;
}

function calcEqual() {
    if (calcPrev === null || calcOperation === null) return;

    let current = parseFloat(calcCurrent);
    let result = 0;

    switch (calcOperation) {
        case "+":
            result = calcPrev + current;
            break;
        case "-":
            result = calcPrev - current;
            break;
        case "*":
            result = calcPrev * current;
            break;
        case "/":
            if (current === 0) {
                alert("Lỗi: Không thể chia cho 0!");
                calcClear();
                return;
            }
            result = calcPrev / current;
            break;
        default:
            return;
    }

    // Làm tròn số thập phân nếu quá dài
    calcCurrent = Math.round(result * 10000000) / 10000000 + "";
    calcPrev = null;
    calcOperation = null;
    calcResetOnNext = true;
    updateCalcScreen();
}
