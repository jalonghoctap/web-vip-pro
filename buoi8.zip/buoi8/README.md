# Buổi 8 - Hoạt động 2: "Logic Builder" - Máy tính mini

> **Học phần:** 111101 · Thiết Kế Web  
> **Giáo trình giảng dạy:** Đại học Lạc Hồng (Trang 59)

---

## 📁 Cấu trúc thư mục

- `index.html`: Giao diện web trực quan, hiện đại, tích hợp cả form web tương tác và nút bấm chạy bằng `prompt()` & `alert()`.
- `style.css`: Định dạng giao diện Glassmorphism, chuẩn responsive trên máy tính và điện thoại.
- `script.js`: Toàn bộ logic JavaScript xử lý điều kiện rẽ nhánh và máy tính mini.
- `logic_builder.js`: File mã nguồn thuần túy ngắn gọn đúng theo mẫu trong giáo trình.

---

## 📝 Nội dung bài thực hành

### 1. Hướng dẫn: Kiểm tra Đạt / Chưa đạt
- **Yêu cầu:** Nhập số điểm. Nếu `điểm >= 5` thì thông báo *"Chúc mừng bạn đã đạt!"*, ngược lại thông báo *"Rất tiếc, hãy cố gắng hơn!"*.
- **Mã nguồn:**
```javascript
let diem = parseFloat(prompt("Nhập vào số điểm của bạn:"));

if (diem >= 5) {
    alert("Chúc mừng bạn đã đạt!");
} else {
    alert("Rất tiếc, hãy cố gắng hơn!");
}
```

### 2. Prompt mẫu: Xếp loại học lực chi tiết
- **Yêu cầu:** Sử dụng `prompt()` lấy điểm, dùng cấu trúc `if - else if - else` và `alert()` kết quả:
  - Điểm > 8: **Giỏi**
  - Điểm > 6.5: **Khá**
  - Điểm >= 5: **Trung bình**
  - Điểm < 5: **Yếu**
- **Mã nguồn:**
```javascript
let diem = parseFloat(prompt("Nhập điểm số:"));

if (diem > 8) {
    alert("Xếp loại: Giỏi");
} else if (diem > 6.5) {
    alert("Xếp loại: Khá");
} else if (diem >= 5) {
    alert("Xếp loại: Trung bình");
} else {
    alert("Xếp loại: Yếu");
}
```

### 3. Mở rộng: Máy tính mini
- Hỗ trợ các phép tính số học: `+`, `-`, `*`, `/`.
- Kiểm tra lỗi chia cho số 0 và nhập ký tự không phải số.

---

## 🚀 Cách chạy và kiểm tra
1. Mở file `index.html` trực tiếp bằng trình duyệt (Chrome, Edge, Firefox, Cốc Cốc, ...).
2. Hoặc sử dụng extension **Live Server** trong VS Code để trải nghiệm đầy đủ các tính năng.
