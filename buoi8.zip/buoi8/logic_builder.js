/**
 * GIÁO TRÌNH GIẢNG DẠY · LẠC HỒNG - TRANG 59
 * HỌC PHẦN 111101 · THIẾT KẾ WEB
 * Hoạt động 2: "Logic Builder" - Máy tính mini (45 phút)
 */

// ==========================================
// 1. Theo "Hướng dẫn": Kiểm tra Đạt / Chưa đạt
// ==========================================
function kiemTraDatTheoHuongDan() {
    let diem = parseFloat(prompt("Nhập vào số điểm của bạn:"));

    if (diem >= 5) {
        alert("Chúc mừng bạn đã đạt!");
    } else {
        alert("Rất tiếc, hãy cố gắng hơn!");
    }
}


// ==========================================
// 2. Theo "Prompt mẫu": Xếp loại học lực
// ==========================================
function xepLoaiTheoPromptMau() {
    let diem = parseFloat(prompt("Nhập điểm số:"));

    if (diem > 8) {
        alert("Giỏi");
    } else if (diem > 6.5) {
        alert("Khá");
    } else if (diem >= 5) {
        alert("Trung bình");
    } else {
        alert("Yếu");
    }
}

// Có thể gọi trực tiếp để kiểm tra:
// kiemTraDatTheoHuongDan();
// xepLoaiTheoPromptMau();
