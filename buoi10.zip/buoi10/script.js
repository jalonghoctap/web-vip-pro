/**
 * ====================================================================
 * GIÁO TRÌNH GIẢNG DẠY · ĐẠI HỌC LẠC HỒNG - BUỔI 10
 * HỌC PHẦN 111101 · THIẾT KẾ WEB
 * - Hoạt động 2: "Light Switch" - Bật/Tắt bóng đèn & Đổi màu nền body
 * - Hoạt động 3: "Live Input" - Phản hồi tức thì với sự kiện 'input'
 * ====================================================================
 */

// ====================================================================
// 0. ĐIỀU HƯỚNG TABS HOẠT ĐỘNG
// ====================================================================

function switchActivity(activityKey) {
    const sectionHd2 = document.getElementById('section-hd2');
    const sectionHd3 = document.getElementById('section-hd3');
    const tabHd2 = document.getElementById('tab-hd2');
    const tabHd3 = document.getElementById('tab-hd3');
    const tabAll = document.getElementById('tab-all');

    // Bỏ active tất cả các tabs
    [tabHd2, tabHd3, tabAll].forEach(t => { if (t) t.classList.remove('active'); });

    if (activityKey === 'hd2') {
        if (sectionHd2) sectionHd2.classList.add('active-section');
        if (sectionHd3) sectionHd3.classList.remove('active-section');
        if (tabHd2) tabHd2.classList.add('active');
        logToTerminal(`[Điều hướng] Chuyển sang Hoạt động 2: "Light Switch"`, 'info');
    } else if (activityKey === 'hd3') {
        if (sectionHd2) sectionHd2.classList.remove('active-section');
        if (sectionHd3) sectionHd3.classList.add('active-section');
        if (tabHd3) tabHd3.classList.add('active');
        logToTerminal(`[Điều hướng] Chuyển sang Hoạt động 3: "Live Input"`, 'info');
    } else {
        // Xem cả hai
        if (sectionHd2) sectionHd2.classList.add('active-section');
        if (sectionHd3) sectionHd3.classList.add('active-section');
        if (tabAll) tabAll.classList.add('active');
        logToTerminal(`[Điều hướng] Hiển thị tất cả hoạt động (HĐ 2 & HĐ 3)`, 'info');
    }
}


// ====================================================================
// 1. HOẠT ĐỘNG 2: "LIGHT SWITCH"
// ====================================================================

const IMG_BULB_OFF = 'images/bulb-off.svg';
const IMG_BULB_ON = 'images/bulb-on.svg';

function batDen() {
    const bulb = document.getElementById('bulb');
    if (!bulb) return;

    bulb.src = IMG_BULB_ON;
    document.body.classList.add('bulb-active');
    updateBulbUI(true);
    playSwitchSound(true);

    logToTerminal(`[DOM] bulb.src = '${IMG_BULB_ON}'`, 'highlight');
    logToTerminal(`> Trạng thái: Đèn đã BẬT SÁNG.`, 'info');
}

function tatDen() {
    const bulb = document.getElementById('bulb');
    if (!bulb) return;

    bulb.src = IMG_BULB_OFF;
    document.body.classList.remove('bulb-active');
    updateBulbUI(false);
    playSwitchSound(false);

    logToTerminal(`[DOM] bulb.src = '${IMG_BULB_OFF}'`, 'highlight');
    logToTerminal(`> Trạng thái: Đèn đã TẮT.`, 'normal');
}

function chuyenDoiBongDen() {
    const bulb = document.getElementById('bulb');
    if (!bulb) return;

    if (bulb.src.includes('bulb-on.svg')) {
        tatDen();
    } else {
        batDen();
    }
}

function updateBulbUI(isOn) {
    const statusText = document.getElementById('bulb-status-text');
    const liveSrc = document.getElementById('live-src-value');
    const badge = document.getElementById('inspector-badge');

    if (statusText) {
        statusText.textContent = isOn ? 'ĐÈN ĐANG SÁNG (ON)' : 'ĐÈN ĐANG TẮT (OFF)';
    }

    if (liveSrc) {
        liveSrc.textContent = isOn ? IMG_BULB_ON : IMG_BULB_OFF;
    }

    if (badge) {
        badge.style.opacity = '1';
        setTimeout(() => { badge.style.opacity = '0.7'; }, 400);
    }
}

// Xử lý nút #toggle-btn (Prompt mẫu HĐ 2)
function setupToggleBtnPrompt() {
    const toggleBtn = document.getElementById('toggle-btn');
    if (!toggleBtn) return;

    toggleBtn.addEventListener('click', function () {
        const body = document.body;
        const currentBg = body.style.backgroundColor;
        const themeIcon = document.getElementById('theme-icon');
        const themeName = document.getElementById('theme-name');
        const themeCode = document.getElementById('theme-code');

        const isCurrentlyDark = (currentBg === 'black' || currentBg === 'rgb(0, 0, 0)');

        if (isCurrentlyDark) {
            body.style.backgroundColor = 'white';
            body.style.color = 'black';
            body.classList.remove('dark-mode');
            body.classList.add('light-mode');

            toggleBtn.innerHTML = '🌙 Chuyển sang Nền Đen (Dark Mode)';
            if (themeIcon) themeIcon.textContent = '☀️';
            if (themeName) themeName.textContent = 'Nền Trắng (Light Mode)';
            if (themeCode) themeCode.textContent = 'backgroundColor: "white"';

            playSwitchSound(false);
            logToTerminal(`[PROMPT HĐ2] Click #toggle-btn: body.style.backgroundColor = 'white'`, 'highlight');
        } else {
            body.style.backgroundColor = 'black';
            body.style.color = 'white';
            body.classList.add('dark-mode');
            body.classList.remove('light-mode');

            toggleBtn.innerHTML = '☀️ Chuyển sang Nền Trắng (Light Mode)';
            if (themeIcon) themeIcon.textContent = '🌙';
            if (themeName) themeName.textContent = 'Nền Đen (Dark Mode)';
            if (themeCode) themeCode.textContent = 'backgroundColor: "black"';

            playSwitchSound(true);
            logToTerminal(`[PROMPT HĐ2] Click #toggle-btn: body.style.backgroundColor = 'black'`, 'highlight');
        }
    });
}


// ====================================================================
// 2. HOẠT ĐỘNG 3: "LIVE INPUT" (PHẢN HỒI TỨC THÌ)
// ====================================================================

/**
 * Phần 1 Hướng dẫn: Lắng nghe sự kiện 'input' và hiển thị vào thẻ <span>
 */
function setupLiveSpan() {
    const nameInput = document.getElementById('name-input');
    const nameSpan = document.getElementById('name-span');
    const charCount = document.getElementById('span-char-count');
    const wordCount = document.getElementById('span-word-count');

    if (nameInput && nameSpan) {
        nameInput.addEventListener('input', function () {
            const val = nameInput.value;

            // 1. Cập nhật thẻ span ngay lập tức
            nameSpan.textContent = val.trim() === '' ? '(Chưa nhập nội dung)' : val;

            // 2. Cập nhật bộ đếm ký tự & từ
            if (charCount) charCount.textContent = val.length;
            if (wordCount) {
                const words = val.trim().split(/\s+/).filter(w => w.length > 0);
                wordCount.textContent = words.length;
            }

            // 3. Ghi log terminal
            logToTerminal(`[EVENT: input] Ô #name-input: "${val}" -> cập nhật thẻ <span>`, 'highlight');
        });
    }
}

/**
 * Nút xóa nhanh nội dung input
 */
function clearLiveSpanInput() {
    const nameInput = document.getElementById('name-input');
    const nameSpan = document.getElementById('name-span');
    const charCount = document.getElementById('span-char-count');
    const wordCount = document.getElementById('span-word-count');

    if (nameInput) {
        nameInput.value = '';
        nameInput.focus();
    }
    if (nameSpan) nameSpan.textContent = '(Chưa nhập nội dung)';
    if (charCount) charCount.textContent = '0';
    if (wordCount) wordCount.textContent = '0';

    logToTerminal(`[Thao tác] Đã xóa trống ô nhập liệu #name-input`, 'normal');
}

/**
 * Phần 2 Prompt mẫu: Lắng nghe sự kiện 'input' và hiển thị vào thẻ <h2> bên dưới
 */
function setupPromptH2() {
    const textInput = document.getElementById('text-input');
    const heading = document.getElementById('heading-output');

    if (textInput && heading) {
        textInput.addEventListener('input', function () {
            const val = textInput.value;

            // Cập nhật ngay lập tức vào thẻ h2 bên dưới
            if (val.trim() === '') {
                heading.textContent = 'Tiêu đề bài viết hiển thị ở đây...';
            } else {
                heading.textContent = val;
            }

            logToTerminal(`[EVENT: input] Ô #text-input: "${val}" -> hiển thị vào thẻ <h2>`, 'info');
        });
    }
}

/**
 * Mô phỏng gõ chữ tự động (Demo sống động cho giám khảo / người xem)
 */
function simulateActivity3() {
    switchActivity('hd3');
    logToTerminal("--- BẮT ĐẦU CHẠY THỬ HOẠT ĐỘNG 3 ---", "info");

    const sampleText1 = "Đại học Lạc Hồng";
    const sampleText2 = "Lập trình Web với JavaScript DOM";

    const input1 = document.getElementById('name-input');
    const input2 = document.getElementById('text-input');

    if (!input1 || !input2) return;

    input1.value = '';
    input2.value = '';

    let i = 0;
    const interval1 = setInterval(() => {
        if (i < sampleText1.length) {
            input1.value += sampleText1[i];
            input1.dispatchEvent(new Event('input'));
            i++;
        } else {
            clearInterval(interval1);

            // Bắt đầu mô phỏng ô 2
            let j = 0;
            const interval2 = setInterval(() => {
                if (j < sampleText2.length) {
                    input2.value += sampleText2[j];
                    input2.dispatchEvent(new Event('input'));
                    j++;
                } else {
                    clearInterval(interval2);
                    logToTerminal("--- HOÀN TẤT CHẠY THỬ HOẠT ĐỘNG 3 ---", "info");
                }
            }, 80);
        }
    }, 90);
}


// ====================================================================
// 3. ÂM THANH CÔNG TẮC VẬT LÝ (WEB AUDIO API)
// ====================================================================

function playSwitchSound(isTurnOn) {
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return;
        const ctx = new AudioContext();

        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(isTurnOn ? 650 : 420, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.05);

        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        osc.stop(ctx.currentTime + 0.05);
    } catch (e) {
        // Bỏ qua lỗi nếu trình duyệt chặn autoplay
    }
}


// ====================================================================
// 4. TERMINAL CONSOLE LOG
// ====================================================================

function logToTerminal(message, type = 'normal') {
    const terminal = document.getElementById('terminal-body');
    if (!terminal) return;

    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];

    const logEntry = document.createElement('div');
    logEntry.className = 'log-entry';

    let msgClass = 'log-msg';
    if (type === 'highlight') msgClass += ' highlight';
    if (type === 'info') msgClass += ' info';
    if (type === 'error') msgClass += ' error';

    logEntry.innerHTML = `
        <span class="log-time">[${timeStr}]</span>
        <span class="log-prefix">&gt;</span>
        <span class="${msgClass}">${message}</span>
    `;

    terminal.appendChild(logEntry);
    terminal.scrollTop = terminal.scrollHeight;
}

function clearTerminal() {
    const terminal = document.getElementById('terminal-body');
    if (terminal) {
        terminal.innerHTML = `
            <div class="log-entry">
                <span class="log-time">[Hệ thống]</span>
                <span class="log-prefix">&gt;</span>
                <span class="log-msg info">Đã xóa sạch nhật ký console.</span>
            </div>
        `;
    }
}

function testConsoleBoth() {
    switchActivity('hd2');
    logToTerminal("--- BẮT ĐẦU CHẠY KIỂM THỬ HOẠT ĐỘNG 2 ---", "info");

    setTimeout(() => { batDen(); }, 400);
    setTimeout(() => { tatDen(); }, 1200);
    setTimeout(() => {
        const toggleBtn = document.getElementById('toggle-btn');
        if (toggleBtn) toggleBtn.click();
    }, 2000);
    setTimeout(() => {
        const toggleBtn = document.getElementById('toggle-btn');
        if (toggleBtn) toggleBtn.click();
        logToTerminal("--- HOÀN TẤT CHUỖI KIỂM THỬ HOẠT ĐỘNG 2 ---", "info");
    }, 3200);
}


// ====================================================================
// 5. KHỞI TẠO KHI TẢI TRANG
// ====================================================================

document.addEventListener('DOMContentLoaded', function () {
    // Khởi tạo Hoạt động 2
    setupToggleBtnPrompt();
    const bulbImg = document.getElementById('bulb');
    if (bulbImg) bulbImg.addEventListener('click', chuyenDoiBongDen);

    // Khởi tạo Hoạt động 3
    setupLiveSpan();
    setupPromptH2();
});
