/**
 * ====================================================================
 * GIÁO TRÌNH THIẾT KẾ WEB · ĐẠI HỌC LẠC HỒNG - BUỔI 10
 * HOẠT ĐỘNG 3: "LIVE INPUT" - PHẢN HỒI TỨC THÌ (30 PHÚT)
 * ====================================================================
 */

// ====================================================================
// PHẦN 1: THEO HƯỚNG DẪN GIÁO TRÌNH
// Yêu cầu: Tạo ô <input>. Khi người dùng gõ chữ, nội dung ngay lập tức
// xuất hiện ở một thẻ <span> bên cạnh.
// ====================================================================

function setupLiveInputSpan() {
    const inputElement = document.getElementById('name-input');
    const spanOutput = document.getElementById('name-span');

    if (inputElement && spanOutput) {
        // Lắng nghe sự kiện 'input' để cập nhật ngay lập tức theo từng ký tự gõ vào
        inputElement.addEventListener('input', function () {
            // Lấy giá trị đang có trong ô input
            const text = inputElement.value;

            // Hiển thị ra thẻ span (nếu rỗng thì hiển thị văn bản mặc định)
            spanOutput.textContent = text || '(Chưa nhập nội dung)';
            console.log("Giá trị input hiện tại:", text);
        });
    }
}


// ====================================================================
// PHẦN 2: THEO PROMPT MẪU
// Prompt mẫu: "Sử dụng sự kiện 'input' trong JavaScript để lấy giá trị
// từ một ô text và hiển thị nó ngay lập tức vào một thẻ h2 bên dưới."
// ====================================================================

function setupPromptInputH2() {
    const textInput = document.getElementById('text-input');
    const headingOutput = document.getElementById('heading-output');

    if (textInput && headingOutput) {
        // Lắng nghe sự kiện 'input'
        textInput.addEventListener('input', function () {
            // Lấy giá trị từ ô text
            const enteredValue = textInput.value;

            // Hiển thị ngay lập tức vào thẻ h2 bên dưới
            if (enteredValue.trim() === '') {
                headingOutput.textContent = 'Tiêu đề hiển thị ở đây...';
            } else {
                headingOutput.textContent = enteredValue;
            }
            console.log("Đã cập nhật thẻ <h2>:", enteredValue);
        });
    }
}

// Khởi chạy khi tài liệu HTML đã sẵn sàng
document.addEventListener('DOMContentLoaded', function () {
    setupLiveInputSpan();
    setupPromptInputH2();
});
