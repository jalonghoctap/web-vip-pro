/**
 * ====================================================================
 * GIÁO TRÌNH THIẾT KẾ WEB · ĐẠI HỌC LẠC HỒNG - BUỔI 10
 * HOẠT ĐỘNG 2: "LIGHT SWITCH" - BẬT/TẮT BÓNG ĐÈN (45 PHÚT)
 * ====================================================================
 */

// ====================================================================
// PHẦN 1: THEO HƯỚNG DẪN GIÁO TRÌNH
// Đổi thuộc tính src của thẻ <img> để Bật/Tắt bóng đèn
// ====================================================================

// Đường dẫn 2 hình ảnh đèn tắt và đèn sáng
const HINH_DEN_TAT = 'images/bulb-off.svg';
const HINH_DEN_SANG = 'images/bulb-on.svg';

/**
 * Cách 1: Hàm riêng biệt Bật đèn
 */
function batDen() {
    const bulb = document.getElementById('bulb');
    if (bulb) {
        bulb.src = HINH_DEN_SANG;
        console.log("Đèn đã BẬT: src =", bulb.src);
    }
}

/**
 * Cách 1: Hàm riêng biệt Tắt đèn
 */
function tatDen() {
    const bulb = document.getElementById('bulb');
    if (bulb) {
        bulb.src = HINH_DEN_TAT;
        console.log("Đèn đã TẮT: src =", bulb.src);
    }
}

/**
 * Cách 2: Một nút bấm chuyển đổi qua lại (Toggle)
 * Kiểm tra thuộc tính src hiện tại: nếu đang sáng thì tắt, nếu đang tắt thì bật
 */
function chuyenDoiBongDen() {
    const bulb = document.getElementById('bulb');
    if (!bulb) return;

    if (bulb.src.includes('bulb-on.svg')) {
        bulb.src = HINH_DEN_TAT;
        console.log("Đã chuyển sang: Đèn Tắt");
    } else {
        bulb.src = HINH_DEN_SANG;
        console.log("Đã chuyển sang: Đèn Sáng");
    }
}


// ====================================================================
// PHẦN 2: THEO PROMPT MẪU (DARK MODE ĐƠN GIẢN)
// "Viết mã JS để khi tôi click vào một nút có id là 'toggle-btn',
//  nó sẽ thay đổi màu nền của body từ trắng sang đen và ngược lại"
// ====================================================================

document.addEventListener('DOMContentLoaded', function () {
    const toggleBtn = document.getElementById('toggle-btn');

    if (toggleBtn) {
        toggleBtn.addEventListener('click', function () {
            // Kiểm tra màu nền hiện tại của thẻ <body>
            const currentColor = document.body.style.backgroundColor;

            if (currentColor === 'black' || currentColor === 'rgb(0, 0, 0)') {
                // Đang màu đen -> Chuyển sang màu trắng (Light Mode)
                document.body.style.backgroundColor = 'white';
                document.body.style.color = 'black';
                toggleBtn.textContent = '🌙 Chuyển sang Nền Đen (Dark Mode)';
                console.log("Màu nền body hiện tại: TRẮNG");
            } else {
                // Đang màu trắng -> Chuyển sang màu đen (Dark Mode)
                document.body.style.backgroundColor = 'black';
                document.body.style.color = 'white';
                toggleBtn.textContent = '☀️ Chuyển sang Nền Trắng (Light Mode)';
                console.log("Màu nền body hiện tại: ĐEN");
            }
        });
    }
});
