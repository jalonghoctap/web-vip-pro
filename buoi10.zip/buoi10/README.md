# Buổi 10 - Thực Hành JavaScript: Thao Tác DOM & Sự Kiện

> **Học phần:** 111101 · Thiết Kế Web  
> **Giáo trình giảng dạy:** Đại học Lạc Hồng  
> **Trọng tâm buổi học:**
> 1. **Hoạt động 2:** "Light Switch" - Bật/Tắt bóng đèn bằng thuộc tính `src` (45 phút)
> 2. **Hoạt động 3:** "Live Input" - Phản hồi tức thì với sự kiện `input` (30 phút)

---

## 📁 Cấu trúc thư mục `buoi10`

| Tên tệp / thư mục | Mục đích sử dụng |
| :--- | :--- |
| `index.html` | Giao diện thực hành tổng hợp tích hợp tab chuyển đổi giữa **Hoạt động 2** và **Hoạt động 3**, Live Inspector, Real-time preview và Virtual Console. |
| `style.css` | Định kiểu hiện đại (Glassmorphism), chuyển đổi Dark/Light mode mượt mà, hiệu ứng phát sáng quầng vàng khi bật đèn. |
| `script.js` | Logic JavaScript điều khiển toàn bộ tương tác cho cả 2 hoạt động và hiệu ứng âm thanh click. |
| `light_switch.js` | Mã nguồn JS thuần túy cho **Hoạt động 2** (Bật/Tắt bóng đèn & Đổi màu nền body). |
| `simple_demo.html` | File HTML tối giản chạy riêng cho **Hoạt động 2**. |
| `live_input.js` | Mã nguồn JS thuần túy cho **Hoạt động 3** (Lắng nghe sự kiện `input`, hiển thị vào `span` và `h2`). |
| `simple_demo_hd3.html` | File HTML tối giản chạy riêng cho **Hoạt động 3**. |
| `images/` | Chứa ảnh vector bóng đèn tắt (`bulb-off.svg`) và đèn sáng (`bulb-on.svg`). |
| `buoi10.docx` | Tài liệu báo cáo bài tập nộp cho giảng viên. |

---

## 📝 NỘI DUNG VÀ LỜI GIẢI CHI TIẾT

---

### PHẦN I: HOẠT ĐỘNG 2 - "LIGHT SWITCH" (BẬT/TẮT BÓNG ĐÈN)

#### 1. Phần Hướng dẫn: Đổi thuộc tính `src` của thẻ `<img>`
* **Yêu cầu:** Tạo một nút bấm và một hình ảnh cái đèn. Khi bấm nút, hình ảnh đổi từ "đèn tắt" sang "đèn sáng" bằng cách thay đổi thuộc tính `src`.
* **Mã HTML:**
  ```html
  <img id="bulb" src="images/bulb-off.svg" alt="Bóng đèn" width="150">
  <button onclick="batDen()">Bật đèn</button>
  <button onclick="tatDen()">Tắt đèn</button>
  ```
* **Mã JavaScript:**
  ```javascript
  function batDen() {
      document.getElementById('bulb').src = 'images/bulb-on.svg';
  }

  function tatDen() {
      document.getElementById('bulb').src = 'images/bulb-off.svg';
  }
  ```

#### 2. Phần Prompt mẫu: Nút `#toggle-btn` đổi màu nền body
* **Yêu cầu:** *"Viết mã JS để khi tôi click vào một nút có id là 'toggle-btn', nó sẽ thay đổi màu nền của body từ trắng sang đen và ngược lại (Dark mode đơn giản)."*
* **Mã HTML:**
  ```html
  <button id="toggle-btn">Chuyển sang Nền Đen</button>
  ```
* **Mã JavaScript:**
  ```javascript
  const toggleBtn = document.getElementById('toggle-btn');

  toggleBtn.addEventListener('click', function () {
      if (document.body.style.backgroundColor === 'black') {
          document.body.style.backgroundColor = 'white';
          document.body.style.color = 'black';
          toggleBtn.textContent = '🌙 Chuyển sang Nền Đen';
      } else {
          document.body.style.backgroundColor = 'black';
          document.body.style.color = 'white';
          toggleBtn.textContent = '☀️ Chuyển sang Nền Trắng';
      }
  });
  ```

---

### PHẦN II: HOẠT ĐỘNG 3 - "LIVE INPUT" (PHẢN HỒI TỨC THÌ)

#### 1. Phần Hướng dẫn: Hiển thị ngay lập tức vào thẻ `<span>` bên cạnh
* **Yêu cầu:** Tạo một ô `<input>`. Khi người dùng gõ chữ vào ô đó, nội dung ngay lập tức xuất hiện ở một thẻ `<span>` bên cạnh.
* **Mã HTML:**
  ```html
  <input type="text" id="name-input" placeholder="Gõ chữ vào đây...">
  <span id="name-span">(Chưa nhập nội dung)</span>
  ```
* **Mã JavaScript:**
  ```javascript
  const nameInput = document.getElementById('name-input');
  const nameSpan = document.getElementById('name-span');

  nameInput.addEventListener('input', function () {
      // Gán giá trị đang có trong input vào textContent của thẻ span
      nameSpan.textContent = nameInput.value || '(Chưa nhập nội dung)';
  });
  ```

#### 2. Phần Prompt mẫu: Hiển thị ngay lập tức vào thẻ `<h2>` bên dưới
* **Yêu cầu:** *"Sử dụng sự kiện 'input' trong JavaScript để lấy giá trị từ một ô text và hiển thị nó ngay lập tức vào một thẻ h2 bên dưới."*
* **Mã HTML:**
  ```html
  <input type="text" id="text-input" placeholder="Nhập tiêu đề...">
  <h2 id="heading-output">Tiêu đề bài viết hiển thị ở đây...</h2>
  ```
* **Mã JavaScript:**
  ```javascript
  const textInput = document.getElementById('text-input');
  const headingOutput = document.getElementById('heading-output');

  textInput.addEventListener('input', function () {
      // Lấy giá trị và gán vào thẻ h2 bên dưới
      headingOutput.textContent = textInput.value || 'Tiêu đề hiển thị ở đây...';
  });
  ```

---

## 🎯 BẢNG SO SÁNH KIẾN THỨC CỐT LÕI (ĐIỀN VÀO BÁO CÁO)

| Khái niệm | Ý nghĩa & Cách dùng | Ví dụ minh họa |
| :--- | :--- | :--- |
| **`element.src`** | Thuộc tính chứa đường dẫn hình ảnh của thẻ `<img>`. Thay đổi thuộc tính này sẽ đổi ảnh trên màn hình. | `bulb.src = 'images/bulb-on.svg'` |
| **Sự kiện `input`** | Kích hoạt ngay lập tức tại thời điểm người dùng gõ thêm, xóa bớt, hoặc dán ký tự vào ô text. | `input.addEventListener('input', fn)` |
| **Sự kiện `change`** | Chỉ kích hoạt khi người dùng nhập xong và click chuột ra ngoài (mất focus/blur) hoặc nhấn phím Enter. | Khác biệt lớn so với `input`. |
| **`element.textContent`**| Thuộc tính an toàn để thay đổi nội dung chữ bên trong một thẻ HTML (`<span>`, `<h2>`, `<p>`). | `heading.textContent = input.value` |
| **`style.backgroundColor`**| Thuộc tính can thiệp trực tiếp vào màu nền CSS của phần tử. | `document.body.style.backgroundColor = 'black'` |
