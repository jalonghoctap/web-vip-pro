# Buổi 3 - Xây Dựng Hệ Thống Lưới: CSS Grid, Flexbox & Tối Ưu Hóa Mã Nguồn

> **Học phần:** 111101 · Thiết Kế Web  
> **Giáo trình giảng dạy:** Đại học Lạc Hồng (Trang 26)  
> **Trọng tâm buổi học:**  
> 1. **Hoạt động 1:** "Flex & Grid Battle" - Giải quyết bài toán căn chỉnh nhanh (30 phút)  
> 2. **Hoạt động 2:** Bài thực hành số 2 - Xây dựng hệ thống lưới cho Portfolio (60 phút)  
> 3. **Hoạt động 3:** Debug & Refactor mã nguồn CSS do AI sinh ra (45 phút)

---

## 📁 Cấu trúc các tệp tin trong thư mục `buoi3/`

Mỗi hoạt động được tổ chức thành **tệp riêng biệt hoàn chỉnh** theo đúng yêu cầu đề bài:

| Tên tệp tin | Hoạt động tương ứng | Mô tả chức năng |
| :--- | :--- | :--- |
| **`hd1_flex_grid_battle.html`** | **Hoạt động 1 (30 phút)** | Giải quyết 3 thử thách căn chỉnh: Căn giữa vật thể, Tạo menu dàn đều, Tạo lưới ảnh 3 cột. Phân tích chi tiết tại sao chọn Flexbox hay Grid. |
| **`index.html`** | **Hoạt động 2 (60 phút)** | Bài thực hành số 2 hoàn chỉnh (tiếp nối Portfolio tuần trước): Bố cục CSS Grid (Main vs Sidebar), Flexbox cho danh sách Skills (`flex-wrap: wrap`), khoảng cách đồng nhất bằng `gap`. |
| **`style.css`** | **CSS Hoạt động 2** | Tệp stylesheet tập trung các kỹ thuật CSS Grid và Flexbox hiện đại cho Portfolio. |
| **`hd3_debug_refactor.html`** | **Hoạt động 3 (45 phút)** | Công cụ so sánh trực quan mã CSS trước và sau Refactor, phân tích 6 thuộc tính dư thừa phổ biến của AI và cách lược bỏ. |
| **`README.md`** | **Báo cáo tổng hợp** | Báo cáo chi tiết lý thuyết, code mẫu và phân tích kỹ thuật của Buổi 3. |

---

## 📝 NỘI DUNG VÀ LỜI GIẢI CHI TIẾT TỪNG HOẠT ĐỘNG

---

### PHẦN I: HOẠT ĐỘNG 1 - "FLEX & GRID BATTLE" (30 PHÚT)

#### 1. Thử thách 1: Căn giữa một vật thể (Center an Element)
* **Giải pháp CSS Grid (Thắng về độ ngắn gọn):**
  ```css
  .container {
      display: grid;
      place-items: center; /* Viết tắt gộp căn giữa cả 2 chiều chỉ với 1 dòng */
      height: 160px;
  }
  ```
* **Giải pháp Flexbox:**
  ```css
  .container {
      display: flex;
      justify-content: center; /* Trục chính (ngang) */
      align-items: center;     /* Trục phụ (dọc) */
      height: 160px;
  }
  ```
* **Giải thích:** Cả 2 đều căn giữa hoàn hảo, nhưng CSS Grid với `place-items: center` ngắn nhất (chỉ 2 dòng code).

---

#### 2. Thử thách 2: Tạo menu dàn đều (Navigation Bar)
* **Giải pháp tối ưu bằng Flexbox:**
  ```css
  .navbar {
      display: flex;
      justify-content: space-between; /* Đẩy logo sang trái, nút sang phải */
      align-items: center;           /* Căn giữa trục dọc */
      gap: 16px;
  }
  ```
* **Giải thích:** Menu là bố cục **1 chiều (1D)** theo phương ngang. Kích thước từng mục phụ thuộc vào độ dài chữ bên trong. Flexbox tự động phân bổ khoảng trống còn thừa một cách tự nhiên nhất.

---

#### 3. Thử thách 3: Tạo lưới ảnh / thẻ 3 cột đều nhau (3-Column Grid)
* **Giải pháp tối ưu bằng CSS Grid:**
  ```css
  .gallery {
      display: grid;
      grid-template-columns: repeat(3, 1fr); /* Chia đều 3 cột với tỷ lệ phân số 1fr */
      gap: 16px;                            /* Khoảng cách đồng nhất */
  }
  ```
* **Giải thích:** Lưới ảnh là bố cục **2 chiều (2D - hàng và cột gióng hàng thẳng tắp)**. Dùng Grid chỉ cần đúng 2 dòng, không phải dùng công thức tính trừ khoảng cách phức tạp `calc((100% - gap) / 3)` như Flexbox.

---

### PHẦN II: HOẠT ĐỘNG 2 - BÀI THỰC HÀNH SỐ 2: HỆ THỐNG LƯỚI CHO PORTFOLIO

Dự án được xây dựng trong tệp [index.html](file:///d:/thiết%20kế%20web/buoi3/index.html) và [style.css](file:///d:/thiết%20kế%20web/buoi3/style.css) đáp ứng chính xác 3 yêu cầu kỹ thuật:

#### 1. Sử dụng CSS Grid chia bố cục tổng thể (Main và Sidebar):
```css
.portfolio-grid-layout {
    display: grid;
    grid-template-columns: 1fr 320px; /* Cột Main chiếm phần còn lại, Sidebar cố định 320px */
    gap: 32px;                        /* Thiết lập khoảng cách đồng nhất bằng gap */
}

/* Responsive trên di động: tự động chuyển sang 1 cột */
@media (max-width: 960px) {
    .portfolio-grid-layout {
        grid-template-columns: 1fr;
        gap: 28px;
    }
}
```

#### 2. Sử dụng Flexbox cho danh sách "Kỹ năng" (Skills) để tự động xuống dòng:
```css
.skills-flex-container {
    display: flex;
    flex-wrap: wrap; /* TỰ ĐỘNG XUỐNG DÒNG KHI THIẾU KHÔNG GIAN */
    gap: 10px;       /* Khoảng cách đồng nhất giữa các thẻ kỹ năng */
}

.skill-tag {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border-radius: 30px;
    /* Tự co giãn theo nội dung chữ */
}
```

#### 3. Thiết lập khoảng cách đồng nhất bằng thuộc tính `gap`:
* `gap: 32px` giữa Main và Sidebar.
* `gap: 32px` giữa các khối `<section>` bên trong Main.
* `gap: 20px` giữa các thẻ `<article>` trong lưới dự án Projects.
* `gap: 10px` giữa các thẻ kỹ năng Flexbox.
* `gap: 10px` giữa các mục trong thanh menu Navbar.

---

### PHẦN III: HOẠT ĐỘNG 3 - DEBUG & REFACTOR MÃ NGUỒN CSS DO AI SINH

Xem giao diện so sánh trực quan trong file [hd3_debug_refactor.html](file:///d:/thiết%20kế%20web/buoi3/hd3_debug_refactor.html).

#### 6 Thuộc tính dư thừa kinh điển mà AI thường chèn vào CSS:
1. **Thừa `width: 100%` trên thẻ khối:** Thẻ `<div>`, `<section>` mặc định đã chiếm toàn bộ chiều rộng. Thêm `width: 100%` cùng với padding/border dễ gây lỗi tràn thanh cuộn ngang (horizontal scrollbar).
2. **Thừa `position: relative` vô tội vạ:** AI hay chèn vào mọi container phòng hờ dù bên trong không hề có phần tử con nào dùng `position: absolute`.
3. **Lạm dụng `!important`:** Phá vỡ tính kế thừa (Cascade Specificity), khiến việc viết responsive sau này bị xung đột.
4. **Tiền tố Vendor Prefixes lỗi thời (`-webkit-`, `-moz-`):** Các thuộc tính như `border-radius`, `box-shadow` đã được tất cả trình duyệt hỗ trợ chuẩn hơn 10 năm qua.
5. **Dùng `float` cùng lúc với `Flexbox/Grid`:** Khi đã là con của Flexbox hoặc Grid, trình duyệt sẽ hoàn toàn bỏ qua `float`.
6. **Lặp khoảng cách kép (Vừa dùng `gap` vừa dùng `margin`):** Đã có `gap: 10px` ở container cha nhưng vẫn đặt thêm `margin-right: 10px` ở item con, làm mép ngoài bị lệch.

---

## 🚀 HƯỚNG DẪN MỞ & KIỂM TRA

1. **Hoạt động 1:** Mở [hd1_flex_grid_battle.html](file:///d:/thiết%20kế%20web/buoi3/hd1_flex_grid_battle.html) để xem 3 thử thách căn chỉnh Flexbox vs Grid.
2. **Hoạt động 2:** Mở [index.html](file:///d:/thiết%20kế%20web/buoi3/index.html) để xem hệ thống lưới CSS Grid và danh sách kỹ năng Flexbox tự xuống dòng khi co giãn trình duyệt.
3. **Hoạt động 3:** Mở [hd3_debug_refactor.html](file:///d:/thiết%20kế%20web/buoi3/hd3_debug_refactor.html) để xem công cụ so sánh trực quan mã CSS trước và sau khi tối ưu hóa.
