/**
 * ====================================================================
 * GIÁO TRÌNH GIẢNG DẠY · ĐẠI HỌC LẠC HỒNG - TRANG 64
 * HỌC PHẦN 111101 · THIẾT KẾ WEB
 * Hoạt động 2: "Function Factory" - Nhà máy xử lý dữ liệu
 * ====================================================================
 */

// ====================================================================
// 1. CÁC HÀM CỐT LÕI (CORE FUNCTIONS ĐÚNG CHUẨN GIÁO TRÌNH)
// ====================================================================

/**
 * Phần 1: Hàm tính diện tích hình chữ nhật
 * @param {number} dai - Chiều dài
 * @param {number} rong - Chiều rộng
 * @returns {number} Diện tích (dài * rộng)
 */
function tinhDienTich(dai, rong) {
    return dai * rong;
}

/**
 * Phần 2: Hàm nhận vào tên và năm sinh, trả về chuỗi lời chào
 * @param {string} ten - Họ và tên người dùng
 * @param {number} namSinh - Năm sinh
 * @returns {string} Chuỗi lời chào kèm số tuổi hiện tại
 */
function chaoNguoiDung(ten, namSinh) {
    const namHienTai = new Date().getFullYear();
    const soTuoi = namHienTai - Number(namSinh);
    return `Chào ${ten}, bạn hiện tại ${soTuoi} tuổi.`;
}


// ====================================================================
// 2. BỘ ĐIỀU KHIỂN CONSOLE ẢO (ON-PAGE TERMINAL LOGGER)
// ====================================================================

function appendToTerminal(message, type = 'normal') {
    const terminal = document.getElementById('terminal-body');
    if (!terminal) return;

    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];

    const logEntry = document.createElement('div');
    logEntry.className = 'log-entry';

    let msgClass = 'log-msg';
    if (type === 'highlight') msgClass += ' highlight';
    if (type === 'info') msgClass += ' info';

    logEntry.innerHTML = `
        <span class="log-time">[${timeStr}]</span>
        <span class="log-prefix">&gt;</span>
        <span class="${msgClass}">${message}</span>
    `;

    terminal.appendChild(logEntry);
    terminal.scrollTop = terminal.scrollHeight;
}

function clearTerminal() {
    const terminal = document.getElementById('terminal-body');
    if (terminal) {
        terminal.innerHTML = `
            <div class="log-entry">
                <span class="log-time">[Hệ thống]</span>
                <span class="log-prefix">&gt;</span>
                <span class="log-msg info">Console đã được làm mới. Sẵn sàng nhận lệnh...</span>
            </div>
        `;
    }
}


// ====================================================================
// 3. XỬ LÝ SỰ KIỆN GIAO DIỆN - PHẦN 1: TÍNH DIỆN TÍCH
// ====================================================================

function tinhDienTichWeb() {
    const daiInput = document.getElementById('dai');
    const rongInput = document.getElementById('rong');

    const dai = parseFloat(daiInput.value);
    const rong = parseFloat(rongInput.value);

    if (isNaN(dai) || isNaN(rong) || dai <= 0 || rong <= 0) {
        alert("Vui lòng nhập chiều dài và chiều rộng là số dương hợp lệ!");
        return;
    }

    // Gọi hàm cốt lõi
    const dienTich = tinhDienTich(dai, rong);

    // Hiển thị kết quả ra UI
    const resultBox = document.getElementById('result-dientich');
    const resultVal = document.getElementById('val-dientich');
    const resultFormula = document.getElementById('formula-dientich');

    resultVal.textContent = `${dienTich.toLocaleString('vi-VN')} (đơn vị vuông)`;
    resultFormula.textContent = `tinhDienTich(${dai}, ${rong}) => ${dai} × ${rong} = ${dienTich}`;
    resultBox.classList.remove('hidden');

    // Cập nhật khung trực quan hình chữ nhật
    updateRectPreview(dai, rong);

    // In ra cả DevTools console và terminal web
    console.log(`[tinhDienTich] dai: ${dai}, rong: ${rong} => Dien tich: ${dienTich}`);
    appendToTerminal(`tinhDienTich(${dai}, ${rong}) = <strong>${dienTich}</strong>`, 'highlight');
}

function updateRectPreview(dai, rong) {
    const preview = document.getElementById('preview-rect');
    if (!preview) return;

    // Giới hạn tỉ lệ hiển thị trong khung
    const maxDimension = 110;
    const minDimension = 40;
    const ratio = dai / rong;

    let width = 120;
    let height = 70;

    if (ratio >= 1) {
        width = Math.min(Math.max(ratio * 60, minDimension), 200);
        height = Math.min(Math.max(width / ratio, minDimension), maxDimension);
    } else {
        height = Math.min(Math.max((1 / ratio) * 50, minDimension), maxDimension);
        width = Math.min(Math.max(height * ratio, minDimension), 200);
    }

    preview.style.width = `${width}px`;
    preview.style.height = `${height}px`;
    preview.textContent = `${dai} × ${rong}`;
}

// Gọi hàm 3 lần với các thông số khác nhau theo đúng đề bài
function chay3LanMau() {
    const sampleCalls = [
        { dai: 5, rong: 3, label: "Lần gọi 1" },
        { dai: 12.5, rong: 4, label: "Lần gọi 2" },
        { dai: 20, rong: 8, label: "Lần gọi 3" }
    ];

    appendToTerminal("--- Bắt đầu gọi hàm tinhDienTich(dai, rong) 3 lần ---", "info");

    sampleCalls.forEach((item, index) => {
        const dt = tinhDienTich(item.dai, item.rong);
        console.log(`[Lần ${index + 1}] tinhDienTich(${item.dai}, ${item.rong}) = ${dt}`);
        appendToTerminal(`Lần ${index + 1}: tinhDienTich(${item.dai}, ${item.rong}) &rarr; Diện tích = <strong>${dt}</strong>`, 'highlight');

        // Cập nhật thẻ hiển thị 3 lần nếu có
        const resEl = document.getElementById(`sample-res-${index + 1}`);
        if (resEl) resEl.textContent = dt;
    });

    const grid = document.getElementById('three-calls-container');
    if (grid) grid.classList.remove('hidden');
}

// Chạy bằng prompt & alert
function chayTinhDienTichPrompt() {
    const inputDai = prompt("Nhập chiều dài hình chữ nhật:", "10");
    if (inputDai === null) return;

    const inputRong = prompt("Nhập chiều rộng hình chữ nhật:", "5");
    if (inputRong === null) return;

    const dai = parseFloat(inputDai);
    const rong = parseFloat(inputRong);

    if (isNaN(dai) || isNaN(rong) || dai <= 0 || rong <= 0) {
        alert("Thông số không hợp lệ!");
        return;
    }

    const ketQua = tinhDienTich(dai, rong);
    alert(`Diện tích hình chữ nhật (${dai} x ${rong}) là: ${ketQua}`);
    console.log(`Prompt: tinhDienTich(${dai}, ${rong}) = ${ketQua}`);
    appendToTerminal(`[Prompt] tinhDienTich(${dai}, ${rong}) = <strong>${ketQua}</strong>`, 'highlight');
}


// ====================================================================
// 4. XỬ LÝ SỰ KIỆN GIAO DIỆN - PHẦN 2: LỜI CHÀO VÀ TÍNH TUỔI
// ====================================================================

function chaoNguoiDungWeb() {
    const tenInput = document.getElementById('ten');
    const namSinhInput = document.getElementById('nam-sinh');

    const ten = tenInput.value.trim();
    const namSinh = parseInt(namSinhInput.value);
    const namHienTai = new Date().getFullYear();

    if (!ten) {
        alert("Vui lòng nhập họ và tên của bạn!");
        return;
    }

    if (isNaN(namSinh) || namSinh < 1900 || namSinh > namHienTai) {
        alert(`Vui lòng nhập năm sinh hợp lệ (từ 1900 đến ${namHienTai})!`);
        return;
    }

    // Gọi hàm cốt lõi
    const ketQua = chaoNguoiDung(ten, namSinh);

    // Hiển thị ra giao diện
    const resultBox = document.getElementById('result-chao');
    const resultVal = document.getElementById('val-chao');

    resultVal.textContent = ketQua;
    resultBox.classList.remove('hidden');

    // In ra console và terminal
    console.log(ketQua);
    appendToTerminal(ketQua, 'highlight');
}

// Chạy bằng prompt & alert
function chayChaoNguoiDungPrompt() {
    const ten = prompt("Nhập tên của bạn:", "Lê Văn Tuấn");
    if (ten === null || ten.trim() === "") return;

    const namSinhStr = prompt("Nhập năm sinh của bạn:", "2004");
    if (namSinhStr === null) return;

    const namSinh = parseInt(namSinhStr);
    const namHienTai = new Date().getFullYear();

    if (isNaN(namSinh) || namSinh < 1900 || namSinh > namHienTai) {
        alert("Năm sinh không hợp lệ!");
        return;
    }

    const ketQua = chaoNguoiDung(ten.trim(), namSinh);
    alert(ketQua);
    console.log("[Prompt Prompt Mẫu]: " + ketQua);
    appendToTerminal(`[Prompt] ${ketQua}`, 'highlight');
}

// Hướng dẫn in kết quả ra Console
function chayDemoConsoleChao() {
    appendToTerminal("--- Demo: Gọi hàm chaoNguoiDung và in kết quả ra Console (F12) ---", "info");

    // Cách 1: Gán vào biến rồi in
    const thongDiep1 = chaoNguoiDung("Nguyễn Văn An", 2004);
    console.log("Cách 1 (Lưu vào biến):", thongDiep1);
    appendToTerminal(`Cách 1: const thongDiep1 = chaoNguoiDung('Nguyễn Văn An', 2004);<br>&rarr; console.log(thongDiep1): <strong>"${thongDiep1}"</strong>`, 'highlight');

    // Cách 2: In trực tiếp
    console.log("Cách 2 (In trực tiếp):", chaoNguoiDung("Trần Thị Bình", 2005));
    appendToTerminal(`Cách 2: console.log(chaoNguoiDung('Trần Thị Bình', 2005));<br>&rarr; In trực tiếp: <strong>"${chaoNguoiDung('Trần Thị Bình', 2005)}"</strong>`, 'highlight');

    // Cách 3: Thêm ví dụ thứ 3
    console.log("Cách 3 (Ví dụ khác):", chaoNguoiDung("Lê Hoàng Nam", 2000));
    appendToTerminal(`Cách 3: console.log(chaoNguoiDung('Lê Hoàng Nam', 2000));<br>&rarr; In trực tiếp: <strong>"${chaoNguoiDung('Lê Hoàng Nam', 2000)}"</strong>`, 'highlight');
}


// ====================================================================
// 5. KHỞI TẠO TỰ ĐỘNG KHI TẢI TRANG
// ====================================================================

window.addEventListener('DOMContentLoaded', () => {
    // In lời chào khởi động vào console thật (F12) và console ảo
    console.log("%c[ĐẠI HỌC LẠC HỒNG] BUỔI 9 - HỌC PHẦN 111101 · THIẾT KẾ WEB", "color: #38bdf8; font-weight: bold; font-size: 14px;");
    console.log("%cHoạt động 2: 'Function Factory' - Nhà máy xử lý dữ liệu (Trang 64)", "color: #818cf8; font-size: 12px;");

    // Chạy mặc định 3 lần gọi mẫu để sinh viên thấy ngay
    chay3LanMau();

    // Chạy mẫu demo console
    const demoChao = chaoNguoiDung("Sinh viên LHU", 2005);
    console.log("Mẫu khởi động:", demoChao);
    appendToTerminal(`Khởi động: ${demoChao}`, 'info');
});
