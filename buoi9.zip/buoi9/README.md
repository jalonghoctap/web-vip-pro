# Buổi 9 - Hoạt động 2: "Function Factory" - Nhà máy xử lý dữ liệu

> **Học phần:** 111101 · Thiết Kế Web  
> **Giáo trình giảng dạy:** Đại học Lạc Hồng (Trang 64)  
> **Thời lượng:** 45 phút  

---

## 📁 Cấu trúc thư mục `buoi9`

- `index.html`: Giao diện ứng dụng trực quan, hiện đại (Glassmorphism dark theme), tích hợp khung mô phỏng hình chữ nhật động, form tính toán và **Live Console Output** đồng bộ với trình duyệt.
- `style.css`: Định kiểu giao diện tương thích responsive hoàn hảo trên mọi thiết bị máy tính, máy tính bảng và điện thoại.
- `script.js`: Toàn bộ logic tương tác giao diện và gọi hàm JavaScript.
- `function_factory.js`: File mã nguồn JavaScript thuần túy ngắn gọn, chú thích chi tiết đúng theo đề bài trong giáo trình.
- `README.md`: Tài liệu hướng dẫn chi tiết và giải thích lý thuyết.

---

## 📝 Nội dung bài thực hành & Lời giải

### 1. Phần "Hướng dẫn": Tính diện tích hình chữ nhật (Trang 64)

- **Yêu cầu:** Viết một hàm `tinhDienTich(dai, rong)` để tính diện tích hình chữ nhật. Gọi hàm này **3 lần** với các thông số khác nhau.
- **Công thức:** `Diện tích = Chiều dài × Chiều rộng`

#### Mã nguồn JavaScript:
```javascript
// Định nghĩa hàm tính diện tích hình chữ nhật
function tinhDienTich(dai, rong) {
    return dai * rong;
}

// Gọi hàm 3 lần với các thông số khác nhau và in kết quả ra console:
let dt1 = tinhDienTich(5, 3);
console.log("Lần 1 (5 x 3): Diện tích =", dt1);       // Kết quả: 15

let dt2 = tinhDienTich(12.5, 4);
console.log("Lần 2 (12.5 x 4): Diện tích =", dt2);   // Kết quả: 50

let dt3 = tinhDienTich(20, 8);
console.log("Lần 3 (20 x 8): Diện tích =", dt3);     // Kết quả: 160
```

---

### 2. Phần "Prompt mẫu": Lời chào và tính tuổi

- **Yêu cầu:** Viết một hàm JavaScript nhận vào tên người dùng và năm sinh, hàm này sẽ trả về chuỗi: `'Chào [Tên], bạn hiện tại [Số tuổi] tuổi'`. Hãy hướng dẫn cách gọi hàm và in kết quả ra console.
- **Công thức tính tuổi:** `Số tuổi = Năm hiện tại - Năm sinh` (Sử dụng `new Date().getFullYear()` để luôn tự động lấy năm hiện tại chính xác).

#### Mã nguồn JavaScript:
```javascript
// Định nghĩa hàm nhận vào tên và năm sinh
function chaoNguoiDung(ten, namSinh) {
    // 1. Lấy năm hiện tại tự động từ hệ thống
    const namHienTai = new Date().getFullYear();
    
    // 2. Tính số tuổi
    const soTuoi = namHienTai - namSinh;
    
    // 3. Trả về chuỗi kết quả (sử dụng Template String ES6)
    return `Chào ${ten}, bạn hiện tại ${soTuoi} tuổi.`;
}

// =================================================================
// HƯỚNG DẪN CÁCH GỌI HÀM VÀ IN KẾT QUẢ RA CONSOLE
// =================================================================

// CÁCH 1: Lưu kết quả trả về vào một biến, sau đó in biến đó ra console
let thongDiep = chaoNguoiDung("Nguyễn Văn An", 2004);
console.log(thongDiep);
// Console hiển thị: Chào Nguyễn Văn An, bạn hiện tại 22 tuổi.

// CÁCH 2: Gọi hàm trực tiếp bên trong console.log()
console.log(chaoNguoiDung("Trần Thị Bình", 2005));
// Console hiển thị: Chào Trần Thị Bình, bạn hiện tại 21 tuổi.

// CÁCH 3: Gọi hàm với bất kỳ đối số nào khác
console.log(chaoNguoiDung("Lê Hoàng Nam", 2000));
// Console hiển thị: Chào Lê Hoàng Nam, bạn hiện tại 26 tuổi.
```

---

## 💡 Kiến thức cốt lõi cần ghi nhớ

1. **Hàm (Function):** Là một khối lệnh độc lập được thiết kế để thực hiện một tác vụ cụ thể, có thể tái sử dụng nhiều lần mà không cần viết lại mã nguồn.
2. **Tham số (Parameters):** Các biến được liệt kê trong khai báo hàm (ví dụ: `dai`, `rong`, `ten`, `namSinh`).
3. **Đối số (Arguments):** Giá trị thực tế được truyền vào hàm khi hàm được gọi (ví dụ: `tinhDienTich(5, 3)` thì `5` và `3` là đối số).
4. **Từ khóa `return`:** Dùng để trả về giá trị sau khi hàm tính toán xong. Khi gặp `return`, hàm sẽ kết thúc ngay lập tức.
5. **Template Literals (Dấu backtick \` \`):** Cho phép nhúng biến trực tiếp vào chuỗi thông qua cú pháp `${bien}` mà không cần phải dùng dấu cộng `+` để nối chuỗi như trước đây.
6. **Kiểm tra kết quả trong DevTools:** Nhấn **F12** (hoặc chuột phải chọn **Inspect/Kiểm tra** &rarr; chuyển sang tab **Console**) trên trình duyệt Chrome / Edge để xem các dòng kết quả từ `console.log()`.

---

## 🚀 Hướng dẫn chạy thử nghiệm

1. **Cách 1: Mở giao diện Web**
   - Click đúp vào file `index.html` để mở trong trình duyệt Chrome, Edge hoặc Cốc Cốc.
   - Trực tiếp nhập các giá trị để xem hình chữ nhật thay đổi kích thước và quan sát khung **Live Console Output** ngay dưới trang web.
   - Nhấn **F12** để quan sát console chính thức của trình duyệt.

2. **Cách 2: Nhúng vào file HTML bất kỳ**
   ```html
   <script src="function_factory.js"></script>
   ```
