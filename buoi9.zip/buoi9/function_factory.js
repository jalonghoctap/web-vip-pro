/**
 * ====================================================================
 * GIÁO TRÌNH GIẢNG DẠY · ĐẠI HỌC LẠC HỒNG - TRANG 64
 * HỌC PHẦN 111101 · THIẾT KẾ WEB
 * Hoạt động 2: "Function Factory" - Nhà máy xử lý dữ liệu (45 phút)
 * ====================================================================
 */

// ====================================================================
// PHẦN 1: THEO "HƯỚNG DẪN" (Trang 64)
// Đề bài: Viết một hàm tinhDienTich(dai, rong) để tính diện tích hình chữ nhật.
//         Gọi hàm này 3 lần với các thông số khác nhau.
// ====================================================================

/**
 * Hàm tính diện tích hình chữ nhật
 * @param {number} dai - Chiều dài hình chữ nhật
 * @param {number} rong - Chiều rộng hình chữ nhật
 * @returns {number} Diện tích hình chữ nhật (dài * rộng)
 */
function tinhDienTich(dai, rong) {
    // Công thức tính diện tích: chiều dài nhân chiều rộng
    return dai * rong;
}

console.log("=== PHẦN 1: TÍNH DIỆN TÍCH HÌNH CHỮ NHẬT ===");

// Gọi hàm lần 1: Chiều dài = 5, Chiều rộng = 3
let dienTich1 = tinhDienTich(5, 3);
console.log("Lần 1 - Kích thước (5 x 3): Diện tích =", dienTich1);

// Gọi hàm lần 2: Chiều dài = 12.5, Chiều rộng = 4
let dienTich2 = tinhDienTich(12.5, 4);
console.log("Lần 2 - Kích thước (12.5 x 4): Diện tích =", dienTich2);

// Gọi hàm lần 3: Chiều dài = 20, Chiều rộng = 8
let dienTich3 = tinhDienTich(20, 8);
console.log("Lần 3 - Kích thước (20 x 8): Diện tích =", dienTich3);



// ====================================================================
// PHẦN 2: THEO "PROMPT MẪU"
// Đề bài: Viết một hàm JavaScript nhận vào tên người dùng và năm sinh,
//         hàm này sẽ trả về chuỗi: 'Chào [Tên], bạn hiện tại [Số tuổi] tuổi'.
//         Hãy hướng dẫn tôi cách gọi hàm và in kết quả ra console.
// ====================================================================

/**
 * Hàm tạo lời chào và tính tuổi người dùng
 * @param {string} ten - Tên người dùng
 * @param {number} namSinh - Năm sinh của người dùng
 * @returns {string} Chuỗi lời chào kèm số tuổi hiện tại
 */
function chaoNguoiDung(ten, namSinh) {
    // Lấy năm hiện tại một cách tự động từ hệ thống
    const namHienTai = new Date().getFullYear();
    
    // Tính tuổi bằng cách lấy năm hiện tại trừ đi năm sinh
    const soTuoi = namHienTai - namSinh;
    
    // Trả về chuỗi kết quả sử dụng Template String (ES6)
    return `Chào ${ten}, bạn hiện tại ${soTuoi} tuổi.`;
}

console.log("\n=== PHẦN 2: LỜI CHÀO VÀ TÍNH TUỔI ===");

// HƯỚNG DẪN CÁCH GỌI HÀM VÀ IN KẾT QUẢ RA CONSOLE:

// Cách 1: Lưu kết quả trả về của hàm vào một biến, sau đó in biến đó ra console
let thongDiep1 = chaoNguoiDung("Nguyễn Văn An", 2004);
console.log(thongDiep1);

// Cách 2: Gọi hàm trực tiếp bên trong câu lệnh console.log()
console.log(chaoNguoiDung("Trần Thị Bình", 2005));

// Cách 3: Gọi hàm với năm sinh bất kỳ khác
console.log(chaoNguoiDung("Lê Hoàng Nam", 2000));
