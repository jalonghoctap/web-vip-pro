# Buổi 12 - Thực Hành JavaScript: Object & Mảng Nâng Cao (Array Methods)

> **Học phần:** 111101 · Thiết Kế Web  
> **Giáo trình giảng dạy:** Đại học Lạc Hồng  
> **Trọng tâm buổi học:**  
> 1. **Hoạt động 1:** "Object Identity" - Định danh đối tượng & Phương thức tính năm sinh (30 phút)  
> 2. **Hoạt động 2:** "The Product Filter" - Bộ lọc sản phẩm với `filter()` & `map()` (45 phút)  
> 3. **Hoạt động 3:** "Dynamic UI Render" - Đổ dữ liệu tự động sinh thẻ `div.card` (30 phút)

---

## 📁 Cấu trúc các tệp tin trong thư mục `buoi12/`

Mỗi hoạt động được tổ chức thành **một tệp riêng biệt hoàn toàn (đầy đủ HTML, CSS, JavaScript tích hợp)** giúp sinh viên nhấp đúp là chạy ngay và dễ dàng nộp bài:

| Tên tệp tin | Hoạt động tương ứng | Mô tả chức năng |
| :--- | :--- | :--- |
| **`hd1_object_identity.html`** | **Hoạt động 1 (30 phút)** | Tạo Object `user` chứa thông tin bản thân, in câu giới thiệu bằng `console.log` và giải đáp Vibe Coding: phương thức `tinhNamSinh()` dùng từ khóa `this`. |
| **`hd2_product_filter.html`** | **Hoạt động 2 (45 phút)** | Mảng 10 Object sản phẩm, lọc các sản phẩm "Đang giảm giá" bằng `filter()` và thực hiện Prompt mẫu: lọc giá > 1 triệu đồng kết hợp `map()` trích xuất tên sản phẩm. |
| **`hd3_dynamic_ui.html`** | **Hoạt động 3 (30 phút)** | Đổ dữ liệu tự động từ mảng JavaScript để sinh các thẻ `div.card` ra giao diện bằng vòng lặp `map()` hoặc `forEach()`. |
| **`index.html`** | **Trang điều hướng tổng** | Bảng điều khiển liên kết nhanh đến cả 3 hoạt động. |
| **`README.md`** | **Tài liệu học tập** | Báo cáo chi tiết lý thuyết, mã nguồn mẫu và câu trả lời Vibe Coding. |

---

## 📝 NỘI DUNG VÀ LỜI GIẢI CHI TIẾT TỪNG HOẠT ĐỘNG

---

### PHẦN I: HOẠT ĐỘNG 1 - "OBJECT IDENTITY" (30 PHÚT)

#### 1. Yêu cầu giáo trình:
* **Hướng dẫn:** Mỗi sinh viên tạo một Object `user` chứa thông tin bản thân (tên, tuổi, chuyên ngành, kỹ năng). Sau đó dùng `console.log` để in ra một câu giới thiệu từ Object đó.
* **Vibe Coding:** Sử dụng AI để hỏi: *"Làm thế nào để thêm một phương thức (function) vào bên trong Object để nó tự tính năm sinh dựa trên thuộc tính tuổi?"*.

#### 2. Mã JavaScript cốt lõi (Xem file `hd1_object_identity.html`):
```javascript
// Khởi tạo Object user chứa thông tin cá nhân
const user = {
    name: "Nguyễn Văn An",
    age: 20,
    major: "Công nghệ thông tin",
    skills: ["HTML", "CSS", "JavaScript", "React"],

    // Phương thức tự tính năm sinh dựa trên thuộc tính tuổi (this.age)
    tinhNamSinh: function () {
        const namHienTai = new Date().getFullYear();
        return namHienTai - this.age; // Dùng 'this' để truy cập thuộc tính trong cùng Object
    },

    // Phương thức tạo câu giới thiệu bản thân
    gioiThieu: function () {
        return `Xin chào! Tôi là ${this.name}, ${this.age} tuổi (sinh năm ${this.tinhNamSinh()}). Tôi đang học chuyên ngành ${this.major}. Kỹ năng của tôi: ${this.skills.join(', ')}.`;
    }
};

// In ra console.log theo yêu cầu đề bài:
console.log(user.gioiThieu());
console.log("Năm sinh tính được:", user.tinhNamSinh());
console.table(user);
```

#### 3. Giải đáp câu hỏi Vibe Coding:
* **Tại sao cần dùng từ khóa `this`?**  
  Bên trong phương thức của Object, từ khóa `this` đại diện cho chính đối tượng đang chứa nó (`user`). Nhờ đó, ta có thể truy xuất thuộc tính `this.age` mà không cần gọi cứng tên biến `user.age` (giúp code linh hoạt, tái sử dụng được).
* **Lưu ý quan trọng:** Không nên dùng Arrow Function `() => {}` khi định nghĩa phương thức trong Object nếu cần dùng `this`, vì Arrow Function không có ngữ cảnh `this` riêng mà sẽ lấy `this` từ phạm vi bên ngoài (window/global).

---

### PHẦN II: HOẠT ĐỘNG 2 - "THE PRODUCT FILTER" (45 PHÚT)

#### 1. Yêu cầu giáo trình:
* **Hướng dẫn:** Giảng viên cung cấp một mảng chứa 10 Object sản phẩm (mỗi sản phẩm có tên và giá). Sinh viên dùng hàm `filter()` để tạo ra một mảng mới chỉ chứa các sản phẩm "Đang giảm giá".
* **Prompt mẫu:** *"Tôi có một mảng danh sách sản phẩm, hãy viết mã JS dùng hàm filter để lọc ra các sản phẩm có giá lớn hơn 1 triệu đồng và dùng map để in tên của chúng ra màn hình."*

#### 2. Dữ liệu mảng 10 sản phẩm mẫu:
```javascript
const products = [
    { id: 1, name: "Tai nghe Bluetooth Sony WH-1000XM5", price: 6990000, isSale: true },
    { id: 2, name: "Bàn phím cơ Akko 3087 v2", price: 1290000, isSale: false },
    { id: 3, name: "Chuột không dây Logitech G304", price: 790000, isSale: true },
    { id: 4, name: "Điện thoại Samsung Galaxy S24", price: 18990000, isSale: true },
    { id: 5, name: "Đồng hồ Apple Watch Series 9", price: 9490000, isSale: false },
    { id: 6, name: "Màn hình Dell UltraSharp 27 inch", price: 8500000, isSale: true },
    { id: 7, name: "Sạc dự phòng Anker 20000mAh", price: 650000, isSale: false },
    { id: 8, name: "Loa Bluetooth JBL Flip 6", price: 2490000, isSale: true },
    { id: 9, name: "Cáp sạc Type-C Baseus 100W", price: 150000, isSale: false },
    { id: 10, name: "Laptop ASUS Zenbook 14 OLED", price: 23990000, isSale: true }
];
```

#### 3. Lời giải theo Hướng dẫn (Lọc sản phẩm Đang giảm giá):
```javascript
// Dùng hàm filter() lọc ra mảng mới chỉ chứa sản phẩm có isSale === true
const saleProducts = products.filter(product => product.isSale === true);

console.log("Danh sách sản phẩm đang giảm giá:", saleProducts);
console.table(saleProducts);
```

#### 4. Lời giải theo Prompt mẫu (Giá > 1 triệu đồng & In tên bằng map):
```javascript
// 1. Dùng filter() lọc sản phẩm có giá > 1.000.000đ
// 2. Dùng map() để trích xuất mảng chỉ gồm tên sản phẩm
const expensiveProductNames = products
    .filter(product => product.price > 1000000)
    .map(product => product.name);

// In tên của từng sản phẩm ra màn hình / console
console.log("Tên các sản phẩm có giá > 1.000.000 đ:", expensiveProductNames);
expensiveProductNames.forEach((name, i) => console.log(`${i + 1}. ${name}`));
```

---

### PHẦN III: HOẠT ĐỘNG 3 - "DYNAMIC UI RENDER" (30 PHÚT)

#### 1. Yêu cầu giáo trình:
* **Hướng dẫn:** Thay vì viết HTML thủ công cho từng sản phẩm, sinh viên dùng vòng lặp `map()` hoặc `forEach()` để tự động tạo ra các thẻ `div.card` trên trang web từ mảng dữ liệu.

#### 2. Phương pháp 1: Dùng `map()` và Template String (Khuyên dùng):
```javascript
const container = document.getElementById('productContainer');

// Duyệt mảng bằng map(), biến đổi mỗi object thành một chuỗi thẻ HTML div.card
const htmlMarkup = products.map(product => `
    <div class="card">
        <span class="card-badge">${product.isSale ? 'Đang giảm giá' : 'Nguyên giá'}</span>
        <h3 class="card-title">${product.name}</h3>
        <div class="card-price">${product.price.toLocaleString('vi-VN')} đ</div>
        <button class="btn-buy" onclick="muaHang('${product.name}')">Chọn Mua</button>
    </div>
`).join(''); // Nối các phần tử của mảng chuỗi thành một chuỗi duy nhất

container.innerHTML = htmlMarkup;
```

#### 3. Phương pháp 2: Dùng `forEach()` và DOM API:
```javascript
const container = document.getElementById('productContainer');
container.innerHTML = ''; // Làm sạch trước khi đổ dữ liệu

products.forEach(product => {
    // Tạo thẻ div
    const card = document.createElement('div');
    card.className = 'card';

    // Đổ nội dung
    card.innerHTML = `
        <h3 class="card-title">${product.name}</h3>
        <div class="card-price">${product.price.toLocaleString('vi-VN')} đ</div>
    `;

    // Gắn thẻ con vào container cha
    container.appendChild(card);
});
```

---

## 🎯 BẢNG SO SÁNH CÁC HÀM XỬ LÝ MẢNG TRONG JAVASCRIPT

| Hàm | Mục đích sử dụng | Giá trị trả về | Có làm biến đổi mảng gốc không? |
| :--- | :--- | :--- | :--- |
| **`filter()`** | Lọc các phần tử thỏa mãn điều kiện logic (`true`/`false`). | **Một mảng mới** chỉ gồm các phần tử thỏa mãn. | ❌ Không (Bảo toàn mảng gốc) |
| **`map()`** | Biến đổi từng phần tử trong mảng thành một giá trị mới (thường dùng sinh mã HTML). | **Một mảng mới** cùng số lượng phần tử với mảng gốc. | ❌ Không (Bảo toàn mảng gốc) |
| **`forEach()`** | Duyệt qua từng phần tử để thực hiện một hành động (side-effect). | `undefined` (Không trả về mảng mới). | ❌ Không |

---

## 🚀 HƯỚNG DẪN MỞ & KIỂM TRA

1. **Mở Hoạt động 1:** Nhấp đúp vào [hd1_object_identity.html](file:///d:/thiết%20kế%20web/buoi12/hd1_object_identity.html) trên trình duyệt, bấm nút **"In Câu Giới Thiệu"** hoặc **"Gọi tinhNamSinh()"** để xem kết quả.
2. **Mở Hoạt động 2:** Nhấp đúp vào [hd2_product_filter.html](file:///d:/thiết%20kế%20web/buoi12/hd2_product_filter.html), bấm nút **"Lọc Đang giảm giá"** hoặc **"Giá > 1 Triệu & In tên"** để quan sát hàm `filter()` và `map()`.
3. **Mở Hoạt động 3:** Nhấp đúp vào [hd3_dynamic_ui.html](file:///d:/thiết%20kế%20web/buoi12/hd3_dynamic_ui.html) để xem các thẻ `div.card` được sinh tự động lên giao diện.
4. Mở [index.html](file:///d:/thiết%20kế%20web/buoi12/index.html) để xem trang chủ điều hướng tổng hợp của Buổi 12.
