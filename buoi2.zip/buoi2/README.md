# Buổi 2 - Cấu Trúc Hóa Web: Semantic HTML5 & Dự Án Portfolio

> **Học phần:** 111101 · Thiết Kế Web  
> **Giáo trình giảng dạy:** Đại học Lạc Hồng  
> **Trọng tâm buổi học:**  
> 1. **Hoạt động 1:** "X-Ray Vision" - Soi cấu trúc Web & Thảo luận thẻ `<aside>` (30 phút)  
> 2. **Hoạt động 2:** Prompting & Coding - Khởi tạo dự án Portfolio cá nhân (`index.html`) (60 phút)

---

## 📁 Cấu trúc các tệp tin trong thư mục `buoi2/`

| Tên tệp tin | Mục đích & Chức năng |
| :--- | :--- |
| **`hd1_xray_vision.html`** | **Hoạt động 1:** Ứng dụng trực quan "X-Ray Vision" soi khung xương HTML cho 3 layout kinh điển (Landing Page, Blog, Dashboard) kèm sơ đồ cây DOM Tree và phần thảo luận chuyên sâu về thẻ `<aside>`. |
| **`index.html`** | **Hoạt động 2:** Dự án Portfolio cá nhân chính thức đáp ứng đầy đủ yêu cầu: có `<header>` (chứa `<nav>`), `<main>` (chứa 5 `<section>` và `<article>`), `<aside>` (sidebar phụ trợ), và `<footer>`. Mã nguồn được chú thích (comment) rõ ràng vai trò của từng thẻ Semantic. |
| **`style.css`** | Định kiểu hiện đại chuẩn Glassmorphism & Dark UI, Responsive 100% trên điện thoại và máy tính cho trang Portfolio. |
| **`README.md`** | Báo cáo chi tiết lý thuyết, câu trả lời thảo luận và bảng tổng hợp thẻ Semantic phục vụ học tập & chấm điểm. |

---

## 📝 NỘI DUNG VÀ LỜI GIẢI CHI TIẾT TỪNG HOẠT ĐỘNG

---

### PHẦN I: HOẠT ĐỘNG 1 - "X-RAY VISION" - SOI CẤU TRÚC WEB (30 PHÚT)

#### 1. Sơ đồ cây (Tree Structure) của 3 layout kinh điển:

##### A. Bố cục Landing Page (Trang đích tiếp thị sản phẩm)
```text
<body>
├── <header>                      // Đầu trang & nhận diện
│   └── <nav>                     // Thanh menu điều hướng chính
├── <main>                        // Nội dung chính duy nhất
│   ├── <section id="hero">       // Khẩu hiệu & nút kêu gọi hành động (CTA)
│   ├── <section id="features">   // Lưới 3 tính năng nổi bật
│   └── <section id="reviews">    // Đánh giá của khách hàng
└── <footer>                      // Chân trang & liên kết mạng xã hội
```

##### B. Bố cục Blog / Trang tin tức (Có cột phụ)
```text
<body>
├── <header>
│   └── <nav>                     // Danh mục chuyên mục báo chí
├── <main>                        // Cột nội dung đọc bài
│   └── <article>                 // Thực thể bài viết hoàn chỉnh
│       ├── <header>              // Tiêu đề bài & thông tin ngày đăng/tác giả
│       ├── <p>                   // Thân bài viết
│       └── <section id="cmt">    // Phân đoạn bình luận
├── <aside>                       // CỘT PHỤ BÊN SƯỜN (SIDEBAR)
│   ├── <section> Tiểu sử tác giả </section>
│   ├── <nav> Bài viết xem nhiều nhất </nav>
│   └── <div class="ads"> Banner quảng cáo </div>
└── <footer>                      // Thông tin tòa soạn & bản quyền
```

##### C. Bố cục Dashboard (Bảng điều khiển quản trị)
```text
<body class="dashboard-layout">
├── <aside>                       // Thanh điều hướng bên sườn trái (Left Sidebar)
│   ├── <div class="logo">
│   └── <nav>                     // Menu điều hướng quản trị
└── <div class="main-wrapper">
    ├── <header>                  // Thanh tìm kiếm trên đỉnh & thông tin Admin
    ├── <main>                    // Nội dung dữ liệu chính
    │   ├── <section id="kpi">    // Thẻ chỉ số tổng quan
    │   └── <section id="table">  // Bảng dữ liệu gần đây
    └── <footer>                  // Trạng thái hệ thống & phiên bản
```

---

#### 2. Thảo luận: "Tại sao vùng này nên dùng `<aside>` mà không phải `<div>`?"

* **Vấn đề của thẻ `<div>`:**  
  `<div>` là thẻ hoàn toàn phi ngữ nghĩa (Non-semantic). Đối với trình duyệt, công cụ tìm kiếm và trình đọc màn hình, `<div>` chỉ là một chiếc hộp vô danh, không mang bất kỳ giá trị thông tin nào về vai trò của khối nội dung.

* **4 Lý do sống còn nên dùng `<aside>`:**
  1. **Ý nghĩa ngữ nghĩa (Semantic Web):** Thẻ `<aside>` thông báo cho trình duyệt biết đây là nội dung **liên quan gián tiếp** hoặc phụ trợ cho nội dung chính xung quanh (như Sidebar, bài viết liên quan, mục lục, quảng cáo, hồ sơ tác giả). Nếu loại bỏ vùng `<aside>`, nội dung chính trong `<main>` vẫn hoàn toàn dễ hiểu và nguyên vẹn.
  2. **Hỗ trợ người khiếm thị (Accessibility / a11y):** Các phần mềm đọc màn hình (Screen Reader - NVDA, JAWS, VoiceOver) nhận diện thẻ `<aside>` như một điểm mốc phụ trợ (`Complementary Landmark`). Người dùng khuyết tật có thể dùng phím tắt để nhảy qua hoặc bỏ qua vùng này nhằm tập trung đọc nội dung chính nhanh hơn.
  3. **Tối ưu hóa công cụ tìm kiếm (SEO):** Thuật toán xếp hạng của Google và Bing đọc hiểu cấu trúc trang: chúng ưu tiên trọng số cho từ khóa nằm trong `<main>` và `<article>`, đồng thời giảm trọng số cho các liên kết ngoài hoặc banner nằm trong `<aside>`.
  4. **Chuẩn hóa mã nguồn & Dễ bảo trì:** Lập trình viên trong nhóm đọc vào mã HTML hiểu ngay đây là thanh bên phụ trợ mà không cần phải đặt thêm các class rườm rà như `<div class="sidebar-right">`.

---

### PHẦN II: HOẠT ĐỘNG 2 - BÀI THỰC HÀNH SỐ 1: DỰ ÁN PORTFOLIO (`index.html`)

Dự án được xây dựng trong tệp [index.html](file:///d:/thiết%20kế%20web/buoi2/index.html) với đầy đủ các khối Semantic HTML5:

| Thẻ Semantic | Vị trí trong dự án Portfolio | Vai trò & Giải thích chi tiết |
| :--- | :--- | :--- |
| **`<header>`** | Đầu trang website | Chứa nhận diện thương hiệu (`An.Dev`) và bọc thanh điều hướng `<nav>`. |
| **`<nav>`** | Nằm bên trong `<header>` | Chứa danh sách các liên kết nhảy nhanh đến các mục: `#about`, `#skills`, `#projects`, `#education`, `#contact`. |
| **`<main>`** | Thân trang website | Vùng nội dung chính duy nhất, chứa 5 phân đoạn `<section>`. |
| **`<section id="about">`** | Section 1 trong `<main>` | Phân đoạn giới thiệu bản sắc cá nhân (Bio, hình đại diện, danh xưng, định hướng nghề nghiệp). |
| **`<section id="skills">`** | Section 2 trong `<main>` | Phân đoạn hiển thị năng lực chuyên môn (Frontend Core, Frameworks, Web Standards). |
| **`<section id="projects">`**| Section 3 trong `<main>` | Phân đoạn danh sách dự án nổi bật, chứa các thẻ `<article>`. |
| **`<article>`** | Nằm trong `<section id="projects">`| Đại diện cho từng thẻ dự án độc lập, hoàn chỉnh (tên dự án, mô tả, công nghệ, link). |
| **`<section id="education">`**| Section 4 trong `<main>` | Quá trình đào tạo tại Đại học Lạc Hồng và chứng chỉ đạt được. |
| **`<section id="contact">`** | Section 5 trong `<main>` | Biểu mẫu liên hệ (Form) tiếp nhận phản hồi từ nhà tuyển dụng. |
| **`<aside>`** | Cột bên phải (Sidebar) | Vùng thông tin bổ trợ: tình trạng sẵn sàng nhận việc, thông tin nhanh (Quick Facts), và châm ngôn công nghệ. |
| **`<footer>`** | Chân trang website | Điểm mốc kết thúc trang: bản quyền tác giả, năm 2026, liên kết mạng xã hội (GitHub, LinkedIn, Email). |

---

## 🚀 HƯỚNG DẪN MỞ & KIỂM TRA BÀI THỰC HÀNH

1. **Kiểm tra Hoạt động 1:** Mở tệp [hd1_xray_vision.html](file:///d:/thiết%20kế%20web/buoi2/hd1_xray_vision.html) trên trình duyệt để trải nghiệm mô hình soi cấu trúc X-Ray và sơ đồ cây DOM Tree cho cả 3 layout.
2. **Kiểm tra Hoạt động 2:** Mở tệp [index.html](file:///d:/thiết%20kế%20web/buoi2/index.html) trên trình duyệt để xem giao diện Portfolio hoàn chỉnh, sau đó nhấp chuột phải chọn **Xem nguồn trang (View Page Source)** hoặc **Kiểm tra (Inspect)** để đối chiếu các dòng chú thích (comment) giải thích thẻ Semantic trong mã HTML.
