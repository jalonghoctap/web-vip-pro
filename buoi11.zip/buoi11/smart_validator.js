/**
 * ====================================================================
 * GIÁO TRÌNH THIẾT KẾ WEB · ĐẠI HỌC LẠC HỒNG (TRANG 70)
 * HOẠT ĐỘNG 2: "SMART VALIDATOR" - BỘ KIỂM TRA THÔNG MINH (45 PHÚT)
 * ====================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const form = document.getElementById('smartForm');
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    const usernameError = document.getElementById('username-error');
    const emailError = document.getElementById('email-error');
    const passwordError = document.getElementById('password-error');

    const alertSuccess = document.getElementById('alertSuccess');
    const alertError = document.getElementById('alertError');
    const meterFill = document.getElementById('meterFill');

    // Checklist Icon Elements
    const iconRuleUsername = document.getElementById('iconRuleUsername');
    const iconRuleEmail = document.getElementById('iconRuleEmail');
    const iconRulePassword = document.getElementById('iconRulePassword');

    // Table Cells
    const valUser = document.getElementById('valUser');
    const statusUser = document.getElementById('statusUser');
    const valEmail = document.getElementById('valEmail');
    const statusEmail = document.getElementById('statusEmail');
    const valPass = document.getElementById('valPass');
    const statusPass = document.getElementById('statusPass');

    // Action Buttons
    const btnInvalidDemo = document.getElementById('btnInvalidDemo');
    const btnValidDemo = document.getElementById('btnValidDemo');
    const btnResetForm = document.getElementById('btnResetForm');
    const btnTogglePassword = document.getElementById('btnTogglePassword');

    // ==========================================================
    // 1. CÁC HÀM VALIDATE RIÊNG CHO TỪNG TRƯỜNG
    // ==========================================================

    /**
     * Quy tắc 1 (Theo Prompt mẫu):
     * "Nếu ô 'username' ít hơn 5 ký tự, hãy hiển thị lỗi 'Tên quá ngắn'
     * vào một thẻ span có class 'error-msg' và đổi border của input sang màu đỏ."
     */
    function validateUsername() {
        const value = usernameInput.value.trim();
        if (valUser) valUser.textContent = value || '(Trống)';

        if (value.length < 5) {
            usernameError.textContent = "⚠️ Tên quá ngắn (tối thiểu 5 ký tự)";
            usernameInput.classList.remove('input-success');
            usernameInput.classList.add('input-error');
            if (iconRuleUsername) iconRuleUsername.textContent = "❌";
            if (statusUser) {
                statusUser.textContent = "LỖI (Quá ngắn)";
                statusUser.className = "badge-invalid";
            }
            return false;
        } else {
            usernameError.textContent = "";
            usernameInput.classList.remove('input-error');
            usernameInput.classList.add('input-success');
            if (iconRuleUsername) iconRuleUsername.textContent = "✅";
            if (statusUser) {
                statusUser.textContent = "HỢP LỆ";
                statusUser.className = "badge-valid";
            }
            return true;
        }
    }

    /**
     * Quy tắc 2 (Theo Hướng dẫn):
     * "Nếu ô Email không có chữ '@', hãy hiển thị thông báo lỗi màu đỏ ngay dưới ô input đó."
     */
    function validateEmail() {
        const value = emailInput.value.trim();
        if (valEmail) valEmail.textContent = value || '(Trống)';

        // Kiểm tra xem chuỗi có chứa ký tự '@' hay không
        if (!value.includes('@')) {
            emailError.textContent = "⚠️ Email không hợp lệ (phải chứa ký tự '@')";
            emailInput.classList.remove('input-success');
            emailInput.classList.add('input-error');
            if (iconRuleEmail) iconRuleEmail.textContent = "❌";
            if (statusEmail) {
                statusEmail.textContent = "LỖI (Thiếu @)";
                statusEmail.className = "badge-invalid";
            }
            return false;
        } else {
            emailError.textContent = "";
            emailInput.classList.remove('input-error');
            emailInput.classList.add('input-success');
            if (iconRuleEmail) iconRuleEmail.textContent = "✅";
            if (statusEmail) {
                statusEmail.textContent = "HỢP LỆ";
                statusEmail.className = "badge-valid";
            }
            return true;
        }
    }

    /**
     * Quy tắc 3 (Theo Hướng dẫn):
     * "Nếu ô Mật khẩu trống, hãy hiển thị thông báo lỗi màu đỏ ngay dưới ô input đó."
     */
    function validatePassword() {
        const value = passwordInput.value;
        if (valPass) valPass.textContent = value ? '••••••••' : '(Trống)';

        // Cập nhật thanh đo độ mạnh mật khẩu
        updatePasswordMeter(value);

        if (value.trim() === '') {
            passwordError.textContent = "⚠️ Mật khẩu không được để trống";
            passwordInput.classList.remove('input-success');
            passwordInput.classList.add('input-error');
            if (iconRulePassword) iconRulePassword.textContent = "❌";
            if (statusPass) {
                statusPass.textContent = "LỖI (Trống)";
                statusPass.className = "badge-invalid";
            }
            return false;
        } else {
            passwordError.textContent = "";
            passwordInput.classList.remove('input-error');
            passwordInput.classList.add('input-success');
            if (iconRulePassword) iconRulePassword.textContent = "✅";
            if (statusPass) {
                statusPass.textContent = "HỢP LỆ";
                statusPass.className = "badge-valid";
            }
            return true;
        }
    }

    // ==========================================================
    // 2. LẮNG NGHE SỰ KIỆN SUBMIT CỦA FORM
    // ==========================================================
    form.addEventListener('submit', function (event) {
        // Chặn reload trang
        event.preventDefault();

        // Ẩn các hộp thông báo cũ
        alertSuccess.style.display = 'none';
        alertError.style.display = 'none';

        // Thực hiện kiểm tra toàn bộ các trường
        const isUserValid = validateUsername();
        const isEmailValid = validateEmail();
        const isPassValid = validatePassword();

        const isFormValid = isUserValid && isEmailValid && isPassValid;

        if (isFormValid) {
            // Tất cả đều thỏa mãn
            alertSuccess.style.display = 'block';
            console.log("%c🎉 [ĐĂNG KÝ THÀNH CÔNG] - Tất cả các quy tắc đã thỏa mãn!", "color: #10b981; font-weight: bold; font-size: 14px;");
            console.log("Dữ liệu xác thực hợp lệ:");
            console.table({
                Username: usernameInput.value.trim(),
                Email: emailInput.value.trim(),
                Password: "•••••••• (Đã bảo mật)"
            });
        } else {
            // Có lỗi
            alertError.style.display = 'block';
            console.warn("❌ [ĐĂNG KÝ THẤT BẠI] - Phát hiện trường thông tin không hợp lệ, vui lòng sửa các ô có viền đỏ!");
        }
    });

    // ==========================================================
    // 3. VALIDATION THỜI GIAN THỰC (REAL-TIME PHẢN HỒI TỨC THÌ)
    // ==========================================================
    usernameInput.addEventListener('input', validateUsername);
    emailInput.addEventListener('input', validateEmail);
    passwordInput.addEventListener('input', validatePassword);

    // ==========================================================
    // 4. TIỆN ÍCH HỖ TRỢ THỬ NGHIỆM (BUTTONS)
    // ==========================================================

    // Thử nhập dữ liệu SAI (Để sinh viên thấy viền đỏ và lỗi xuất hiện đồng loạt)
    if (btnInvalidDemo) {
        btnInvalidDemo.addEventListener('click', () => {
            usernameInput.value = "abc"; // < 5 ký tự
            emailInput.value = "an.nguyen.gmail.com"; // không có @
            passwordInput.value = ""; // để trống

            validateUsername();
            validateEmail();
            validatePassword();

            alertSuccess.style.display = 'none';
            alertError.style.display = 'block';
            console.log("ℹ️ Đã nạp dữ liệu SAI để kiểm tra hiển thị lỗi đỏ.");
        });
    }

    // Thử nhập dữ liệu ĐÚNG
    if (btnValidDemo) {
        btnValidDemo.addEventListener('click', () => {
            usernameInput.value = "nguyenan2026"; // >= 5 ký tự
            emailInput.value = "an.nguyen@lhu.edu.vn"; // có @
            passwordInput.value = "MatKhauBaoMat@123"; // không trống

            validateUsername();
            validateEmail();
            validatePassword();

            alertError.style.display = 'none';
            alertSuccess.style.display = 'block';
            console.log("ℹ️ Đã nạp dữ liệu ĐÚNG để kiểm tra viền xanh và trạng thái thành công.");
        });
    }

    // Nút làm mới Form
    if (btnResetForm) {
        btnResetForm.addEventListener('click', () => {
            form.reset();
            usernameInput.className = "form-control";
            emailInput.className = "form-control";
            passwordInput.className = "form-control";
            usernameError.textContent = "";
            emailError.textContent = "";
            passwordError.textContent = "";
            alertSuccess.style.display = 'none';
            alertError.style.display = 'none';
            if (meterFill) meterFill.style.width = "0%";

            if (iconRuleUsername) iconRuleUsername.textContent = "⚪";
            if (iconRuleEmail) iconRuleEmail.textContent = "⚪";
            if (iconRulePassword) iconRulePassword.textContent = "⚪";

            if (valUser) valUser.textContent = '(Trống)';
            if (valEmail) valEmail.textContent = '(Trống)';
            if (valPass) valPass.textContent = '(Trống)';

            if (statusUser) { statusUser.textContent = "CHỜ KIỂM TRA"; statusUser.className = ""; }
            if (statusEmail) { statusEmail.textContent = "CHỜ KIỂM TRA"; statusEmail.className = ""; }
            if (statusPass) { statusPass.textContent = "CHỜ KIỂM TRA"; statusPass.className = ""; }
        });
    }

    // Nút ẩn/hiện mật khẩu
    if (btnTogglePassword) {
        btnTogglePassword.addEventListener('click', () => {
            const isPassword = passwordInput.getAttribute('type') === 'password';
            passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
            btnTogglePassword.textContent = isPassword ? '🙈' : '👁️';
        });
    }

    // Thanh đo độ mạnh mật khẩu
    function updatePasswordMeter(pass) {
        if (!meterFill) return;
        if (!pass) {
            meterFill.style.width = "0%";
            return;
        }

        let strength = 0;
        if (pass.length >= 6) strength += 30;
        if (pass.length >= 10) strength += 30;
        if (/[A-Z]/.test(pass) && /[0-9]/.test(pass)) strength += 20;
        if (/[^A-Za-z0-9]/.test(pass)) strength += 20;

        meterFill.style.width = `${strength}%`;
        if (strength <= 30) {
            meterFill.style.backgroundColor = "var(--error)";
        } else if (strength <= 70) {
            meterFill.style.backgroundColor = "var(--warning)";
        } else {
            meterFill.style.backgroundColor = "var(--success)";
        }
    }
});
