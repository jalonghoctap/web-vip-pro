/**
 * ====================================================================
 * GIÁO TRÌNH THIẾT KẾ WEB · BUỔI 11
 * HOẠT ĐỘNG 3: "DATA COLLECTOR" - THU THẬP DỮ LIỆU (30 PHÚT)
 * ====================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const form = document.getElementById('collectorForm');
    const fullnameInput = document.getElementById('fullname');
    const emailInput = document.getElementById('email');
    const expSelect = document.getElementById('experience');

    // Profile Preview Elements
    const previewAvatar = document.getElementById('previewAvatar');
    const previewName = document.getElementById('previewName');
    const previewEmail = document.getElementById('previewEmail');
    const previewGender = document.getElementById('previewGender');
    const previewHobbiesContainer = document.getElementById('previewHobbies');
    const jsonOutput = document.getElementById('jsonOutput');

    // Buttons
    const btnPresetMale = document.getElementById('btnPresetMale');
    const btnPresetFemale = document.getElementById('btnPresetFemale');
    const btnReset = document.getElementById('btnReset');
    const btnCopyJson = document.getElementById('btnCopyJson');

    // ==========================================================
    // 1. HÀM THU THẬP VÀ ĐÓNG GÓI ĐỐI TƯỢNG (OBJECT)
    // ==========================================================
    function collectUserData() {
        // A. Thu thập từ Text Input & Select
        const fullName = fullnameInput.value.trim() || "Chưa nhập tên";
        const email = emailInput.value.trim() || "Chưa nhập email";
        const experience = expSelect ? expSelect.value : "Cơ bản";

        // B. Thu thập từ Radio Button (Giới tính)
        // Dùng CSS Selector :checked để lấy radio duy nhất đang được chọn
        const checkedGender = document.querySelector('input[name="gender"]:checked');
        const gender = checkedGender ? checkedGender.value : "Chưa chọn";

        // C. Thu thập từ Checkbox (Sở thích - nhiều lựa chọn)
        // Dùng querySelectorAll để lấy danh sách tất cả checkbox có :checked
        const checkedHobbies = document.querySelectorAll('input[name="hobbies"]:checked');
        const hobbiesList = [];
        checkedHobbies.forEach((cb) => {
            hobbiesList.push(cb.value);
        });

        // D. ĐÓNG GÓI THÀNH MỘT ĐỐI TƯỢNG (OBJECT) DỮ LIỆU HOÀN CHỈNH
        const userProfile = {
            fullName: fullName,
            email: email,
            gender: gender,
            hobbies: hobbiesList,
            totalHobbies: hobbiesList.length,
            experience: experience,
            collectedAt: new Date().toLocaleTimeString('vi-VN')
        };

        return userProfile;
    }

    // ==========================================================
    // 2. CẬP NHẬT GIAO DIỆN PREVIEW & JSON VIEWER
    // ==========================================================
    function updateUI(profile) {
        // Cập nhật Avatar dựa trên Giới tính
        if (profile.gender === "Nam") {
            previewAvatar.textContent = "👨‍💻";
        } else if (profile.gender === "Nữ") {
            previewAvatar.textContent = "👩‍💻";
        } else {
            previewAvatar.textContent = "🧑‍💻";
        }

        previewName.textContent = profile.fullName;
        previewEmail.textContent = profile.email;
        previewGender.textContent = `Giới tính: ${profile.gender}`;

        // Cập nhật danh sách badges sở thích
        previewHobbiesContainer.innerHTML = '';
        if (profile.hobbies.length > 0) {
            profile.hobbies.forEach(hobby => {
                const badge = document.createElement('span');
                badge.className = 'badge-tag';
                badge.textContent = hobby;
                previewHobbiesContainer.appendChild(badge);
            });
        } else {
            const emptySpan = document.createElement('span');
            emptySpan.style.fontSize = '12px';
            emptySpan.style.color = 'var(--text-muted)';
            emptySpan.textContent = '(Chưa chọn sở thích)';
            previewHobbiesContainer.appendChild(emptySpan);
        }

        // Cập nhật JSON Viewer
        jsonOutput.textContent = JSON.stringify(profile, null, 2);
    }

    // ==========================================================
    // 3. XỬ LÝ SỰ KIỆN FORM SUBMIT
    // ==========================================================
    form.addEventListener('submit', function (event) {
        // Chặn tải lại trang
        event.preventDefault();

        // Thu thập đối tượng
        const userObject = collectUserData();

        // Cập nhật giao diện
        updateUI(userObject);

        // IN RA CONSOLE.LOG THEO YÊU CẦU ĐỀ BÀI
        console.group("📦 [Hoạt động 3: Data Collector] - Đối tượng người dùng hoàn chỉnh");
        console.log("✔ Đối tượng JavaScript (User Object):", userObject);
        console.log("✔ Định dạng JSON:", JSON.stringify(userObject));
        console.table(userObject);
        console.groupEnd();
    });

    // ==========================================================
    // 4. LẮNG NGHE REAL-TIME KHI NGƯỜI DÙNG THAY ĐỔI LỰA CHỌN
    // ==========================================================
    form.addEventListener('change', () => {
        const userObject = collectUserData();
        updateUI(userObject);
    });

    fullnameInput.addEventListener('input', () => {
        const userObject = collectUserData();
        updateUI(userObject);
    });

    // ==========================================================
    // 5. CÁC NÚT TIỆN ÍCH MẪU NHANH
    // ==========================================================
    if (btnPresetMale) {
        btnPresetMale.addEventListener('click', () => {
            fullnameInput.value = "Trần Minh Quân";
            emailInput.value = "quan.tran@gmail.com";
            
            // Chọn radio Nam
            const radioMale = document.querySelector('input[name="gender"][value="Nam"]');
            if (radioMale) radioMale.checked = true;

            // Đặt các checkbox
            const targetHobbies = ["Lập trình web 💻", "Chơi game 🎮", "Thể thao ⚽"];
            document.querySelectorAll('input[name="hobbies"]').forEach(cb => {
                cb.checked = targetHobbies.includes(cb.value);
            });

            const userObject = collectUserData();
            updateUI(userObject);
            console.log("⚡ Đã chọn mẫu nhanh: Học viên Nam (IT & Gamer)");
        });
    }

    if (btnPresetFemale) {
        btnPresetFemale.addEventListener('click', () => {
            fullnameInput.value = "Lê Thùy Trang";
            emailInput.value = "trang.le@lhu.edu.vn";
            
            // Chọn radio Nữ
            const radioFemale = document.querySelector('input[name="gender"][value="Nữ"]');
            if (radioFemale) radioFemale.checked = true;

            // Đặt các checkbox
            const targetHobbies = ["Đọc sách 📚", "Nghe nhạc 🎵", "Du lịch ✈️", "Nhiếp ảnh 📸"];
            document.querySelectorAll('input[name="hobbies"]').forEach(cb => {
                cb.checked = targetHobbies.includes(cb.value);
            });

            const userObject = collectUserData();
            updateUI(userObject);
            console.log("⚡ Đã chọn mẫu nhanh: Học viên Nữ (Reader & Traveler)");
        });
    }

    if (btnReset) {
        btnReset.addEventListener('click', () => {
            form.reset();
            setTimeout(() => {
                const userObject = collectUserData();
                updateUI(userObject);
            }, 50);
        });
    }

    if (btnCopyJson) {
        btnCopyJson.addEventListener('click', () => {
            const text = jsonOutput.textContent;
            navigator.clipboard.writeText(text).then(() => {
                const originalText = btnCopyJson.textContent;
                btnCopyJson.textContent = "✅ Đã sao chép!";
                setTimeout(() => {
                    btnCopyJson.textContent = originalText;
                }, 2000);
            });
        });
    }

    // Khởi tạo ban đầu
    const initialProfile = collectUserData();
    updateUI(initialProfile);
});
