# Buổi 11 - Thực Hành JavaScript: Xử Lý Form, Validation & Thu Thập Dữ Liệu

> **Học phần:** 111101 · Thiết Kế Web  
> **Giáo trình giảng dạy:** Đại học Lạc Hồng  
> **Trọng tâm buổi học:**  
> 1. **Hoạt động 1:** "Stop the Page!" - Chặn tải lại trang với `event.preventDefault()` (30 phút)  
> 2. **Hoạt động 2:** "Smart Validator" - Bộ kiểm tra thông minh & Viền đỏ báo lỗi (45 phút)  
> 3. **Hoạt động 3:** "Data Collector" - Thu thập dữ liệu Checkbox & Radio button thành Object (30 phút)

---

## 📁 Cấu trúc các tệp tin trong thư mục `buoi11/`

### 🔵 Phần Hoạt động 1: "Stop the Page!" (Chặn tải lại trang)
| Tên tệp tin | Chức năng |
| :--- | :--- |
| **`simple_demo.html`** | File HTML độc lập, tối giản cho Hoạt động 1 (dễ hiểu, dễ nộp bài). |
| **`stop_the_page.js`** | Logic JavaScript chặn sự kiện `submit`, gọi `event.preventDefault()` và in `console.log`. |
| **`index.html`** | Ứng dụng tương tác nâng cao cho HĐ1 kèm Virtual Console ảo, bảng so sánh và Vibe Coding. |
| **`style.css`** & **`script.js`** | CSS và JS xử lý giao diện cho `index.html`. |

### 🟣 Phần Hoạt động 2: "Smart Validator" (Bộ kiểm tra thông minh)
| Tên tệp tin | Chức năng |
| :--- | :--- |
| **`simple_demo_hd2.html`** | File HTML độc lập, gọn gàng cho Hoạt động 2 theo chuẩn giáo trình trang 70. |
| **`smart_validator.html`** | Giao diện đăng ký hoàn chỉnh cho Hoạt động 2 với live validation, checklist và debug table. |
| **`smart_validator.css`** | Định kiểu riêng cho HĐ2: viền đỏ `.input-error`, viền xanh `.input-success`, nhãn lỗi `.error-msg`. |
| **`smart_validator.js`** | Xử lý kiểm tra điều kiện `username` (< 5 ký tự), `email` (thiếu `@`), `password` (trống). |

### 🟢 Phần Hoạt động 3: "Data Collector" (Thu thập dữ liệu)
| Tên tệp tin | Chức năng |
| :--- | :--- |
| **`simple_demo_hd3.html`** | File HTML độc lập, tinh gọn cho Hoạt động 3: thu thập Checkbox & Radio thành Object. |
| **`data_collector.html`** | Giao diện thu thập dữ liệu hiện đại, Profile Card trực tiếp, JSON Inspector và các preset nhanh. |
| **`data_collector.css`** | Định kiểu riêng cho HĐ3: Radio/Checkbox Chips đẹp mắt, JSON box màu dark theme. |
| **`data_collector.js`** | Logic trích xuất Radio `:checked`, Checkbox `:checked` và đóng gói thành User Object. |

---

## 📝 NỘI DUNG VÀ LỜI GIẢI CHI TIẾT

---

### PHẦN I: HOẠT ĐỘNG 1 - "STOP THE PAGE!" (30 PHÚT)

* **Hướng dẫn:** Tạo một Form đơn giản. Khi nhấn "Gửi", trang web thường bị load lại. Sinh viên dùng `event.preventDefault()` để chặn hành vi này và in dữ liệu ra `console.log`.
* **Vibe Coding:** *"Tại sao tôi cần dùng `preventDefault()` khi xử lý Form bằng JavaScript?"*

#### Mã JavaScript cốt lõi:
```javascript
const form = document.getElementById('contactForm');

form.addEventListener('submit', function (event) {
    // Chặn tải lại trang mặc định
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;

    console.log("Dữ liệu gửi lên:", { name, email });
});
```

---

### PHẦN II: HOẠT ĐỘNG 2 - "SMART VALIDATOR" (45 PHÚT - TRANG 70)

* **Hướng dẫn:** Xây dựng Form đăng ký. Nếu ô Email không có chữ `"@"` hoặc ô Mật khẩu trống, hãy hiển thị thông báo lỗi màu đỏ ngay dưới ô input đó.
* **Prompt mẫu:** *"Viết mã JS để kiểm tra một Form: Nếu ô 'username' ít hơn 5 ký tự, hãy hiển thị lỗi 'Tên quá ngắn' vào một thẻ span có class 'error-msg' và đổi border của input sang màu đỏ."*

#### Mã JavaScript cốt lõi:
```javascript
form.addEventListener('submit', function (event) {
    event.preventDefault();
    let isValid = true;

    // 1. Username ít hơn 5 ký tự
    if (usernameInput.value.trim().length < 5) {
        usernameError.textContent = "Tên quá ngắn";
        usernameInput.classList.add('input-error');
        isValid = false;
    } else {
        usernameError.textContent = "";
        usernameInput.classList.remove('input-error');
    }

    // 2. Email thiếu '@'
    if (!emailInput.value.includes('@')) {
        emailError.textContent = "Email không hợp lệ (phải chứa '@')";
        emailInput.classList.add('input-error');
        isValid = false;
    } else {
        emailError.textContent = "";
        emailInput.classList.remove('input-error');
    }

    // 3. Password để trống
    if (passwordInput.value.trim() === '') {
        passwordError.textContent = "Mật khẩu không được để trống";
        passwordInput.classList.add('input-error');
        isValid = false;
    } else {
        passwordError.textContent = "";
        passwordInput.classList.remove('input-error');
    }
});
```

---

### PHẦN III: HOẠT ĐỘNG 3 - "DATA COLLECTOR" (30 PHÚT)

* **Hướng dẫn:** Thu thập dữ liệu từ Checkbox (Sở thích) và Radio button (Giới tính) để tạo thành một đối tượng (Object) dữ liệu người dùng hoàn chỉnh.

#### 1. Nguyên lý thu thập
* **Radio button (Chọn duy nhất 1):** Dùng `document.querySelector('input[name="gender"]:checked')` để lấy radio đang được chọn.
* **Checkbox (Chọn nhiều):** Dùng `document.querySelectorAll('input[name="hobbies"]:checked')` và duyệt qua bằng vòng lặp `forEach()` để đưa vào một mảng `Array`.
* **Đóng gói Object:** Gộp các biến vào một đối tượng `{ ... }` có cấu trúc rõ ràng.

#### 2. Mã JavaScript cốt lõi (Xem tệp `simple_demo_hd3.html`):
```javascript
form.addEventListener('submit', function (event) {
    event.preventDefault(); // Chặn reload

    // 1. Lấy Họ tên
    const fullname = document.getElementById('fullname').value.trim();

    // 2. Thu thập Giới tính từ Radio Button
    const genderRadio = document.querySelector('input[name="gender"]:checked');
    const gender = genderRadio ? genderRadio.value : "Chưa chọn";

    // 3. Thu thập Sở thích từ các Checkbox
    const selectedHobbies = [];
    const hobbyCheckboxes = document.querySelectorAll('input[name="hobbies"]:checked');
    hobbyCheckboxes.forEach(function (cb) {
        selectedHobbies.push(cb.value);
    });

    // 4. Đóng gói thành Đối tượng (Object) người dùng hoàn chỉnh
    const userProfile = {
        fullname: fullname,
        gender: gender,
        hobbies: selectedHobbies,
        totalHobbies: selectedHobbies.length,
        collectedAt: new Date().toLocaleTimeString('vi-VN')
    };

    // 5. In ra Console dạng Object và Bảng
    console.log("Đối tượng người dùng hoàn chỉnh:", userProfile);
    console.table(userProfile);
});
```

---

## 🎯 BẢNG SO SÁNH CÁCH THU THẬP CÁC LOẠI DỮ LIỆU FORM

| Loại trường | Cú pháp HTML | Cách lấy giá trị trong JavaScript | Kiểu dữ liệu nhận được |
| :--- | :--- | :--- | :--- |
| **Text / Email / Pass** | `<input type="text">` | `inputElement.value.trim()` | Chuỗi (`String`) |
| **Radio Button** | `<input type="radio" name="gender">` | `document.querySelector('input[name="gender"]:checked')?.value` | Chuỗi (`String`) |
| **Checkbox** | `<input type="checkbox" name="hobbies">` | `document.querySelectorAll('input[name="hobbies"]:checked')` &rarr; `forEach()` | Mảng chuỗi (`Array<String>`) |
| **Select / Dropdown**| `<select id="major">` | `selectElement.value` | Chuỗi (`String`) |

---

## 🔍 HƯỚNG DẪN MỞ & KIỂM TRA

1. **Hoạt động 1:** Mở [simple_demo.html](file:///d:/thiết%20kế%20web/buoi11/simple_demo.html) hoặc [index.html](file:///d:/thiết%20kế%20web/buoi11/index.html) &rarr; Bấm Gửi để xem dữ liệu log ra Console mà không reload trang.
2. **Hoạt động 2:** Mở [simple_demo_hd2.html](file:///d:/thiết%20kế%20web/buoi11/simple_demo_hd2.html) hoặc [smart_validator.html](file:///d:/thiết%20kế%20web/buoi11/smart_validator.html) &rarr; Thử nhập sai hoặc bấm nút **"Thử dữ liệu SAI"** để xem viền đỏ và thông báo chữ đỏ.
3. **Hoạt động 3:** Mở [simple_demo_hd3.html](file:///d:/thiết%20kế%20web/buoi11/simple_demo_hd3.html) hoặc [data_collector.html](file:///d:/thiết%20kế%20web/buoi11/data_collector.html) &rarr; Chọn các ô Giới tính, Sở thích và bấm **"Đóng Gói Đối Tượng"** để xem cấu trúc Object JSON sinh ra theo thời gian thực.
