/**
 * ====================================================================
 * GIÁO TRÌNH THIẾT KẾ WEB · BUỔI 11
 * HOẠT ĐỘNG 1: "STOP THE PAGE!" - CHẶN TẢI LẠI TRANG (30 PHÚT)
 * ====================================================================
 * 
 * Mục tiêu:
 * 1. Hiểu được hành vi mặc định của thẻ <form> (trình duyệt gửi request và tải lại trang).
 * 2. Sử dụng event.preventDefault() trong sự kiện 'submit' để chặn việc reload trang.
 * 3. Trích xuất giá trị từ các trường nhập liệu và in dữ liệu ra console.log.
 */

// Lấy tham chiếu đến phần tử <form> thông qua ID
const form = document.getElementById('contactForm');
const resultBox = document.getElementById('resultBox');

// Lắng nghe sự kiện 'submit' của Form
form.addEventListener('submit', function (event) {
    // -------------------------------------------------------------
    // BƯỚC 1: DÙNG event.preventDefault() ĐỂ CHẶN TẢI LẠI TRANG
    // -------------------------------------------------------------
    // Mặc định khi người dùng bấm nút submit hoặc ấn Enter trong form,
    // trình duyệt sẽ thực hiện submit form và LOAD LẠI TRANG.
    // Lệnh này ngăn chặn hành vi mặc định đó, giữ nguyên trạng thái trang web.
    event.preventDefault();

    // -------------------------------------------------------------
    // BƯỚC 2: TRÍCH XUẤT GIÁ TRỊ TỪ CÁC Ô NHẬP LIỆU (INPUT/TEXTAREA)
    // -------------------------------------------------------------
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const messageInput = document.getElementById('message');

    const formData = {
        name: nameInput.value.trim(),
        email: emailInput.value.trim(),
        message: messageInput.value.trim(),
        submittedAt: new Date().toLocaleTimeString('vi-VN')
    };

    // -------------------------------------------------------------
    // BƯỚC 3: IN DỮ LIỆU RA CONSOLE.LOG THEO YÊU CẦU ĐỀ BÀI
    // -------------------------------------------------------------
    console.log("%c🛑 [Hoạt động 1: Stop the Page!] - Form Submit Event Intercepted!", "color: #1976d2; font-weight: bold; font-size: 14px;");
    console.log("✔ Đã gọi: event.preventDefault() -> Trang web KHÔNG bị load lại!");
    console.log("✔ Dữ liệu người dùng vừa nhập:");
    console.log("   - Họ và tên :", formData.name);
    console.log("   - Email     :", formData.email);
    console.log("   - Tin nhắn  :", formData.message);
    console.log("   - Thời gian :", formData.submittedAt);
    
    // In dưới dạng bảng trực quan (Table view trong F12 Console)
    console.table(formData);

    // -------------------------------------------------------------
    // BƯỚC 4: PHẢN HỒI GIAO DIỆN NGƯỜI DÙNG (UI FEEDBACK)
    // -------------------------------------------------------------
    if (resultBox) {
        resultBox.style.display = 'block';
        resultBox.innerHTML = `
            ✅ <strong>Thành công!</strong> Đã chặn tải lại trang bằng <code>event.preventDefault()</code>.<br>
            <span style="font-size: 13px; color: #1b5e20;">
                👤 <strong>Họ tên:</strong> ${formData.name} | 
                📧 <strong>Email:</strong> ${formData.email} | 
                🕒 <strong>Lúc:</strong> ${formData.submittedAt}
            </span>
        `;
    }
});
