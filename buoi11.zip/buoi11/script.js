/**
 * ====================================================================
 * GIÁO TRÌNH THIẾT KẾ WEB · BUỔI 11
 * HOẠT ĐỘNG 1: "STOP THE PAGE!" - CHẶN TẢI LẠI TRANG (30 PHÚT)
 * Logic ứng dụng tương tác & Virtual Console Inspector
 * ====================================================================
 */

// Trạng thái ứng dụng
const AppState = {
    isPreventDefaultActive: true,
    submitCount: 0,
    startTime: Date.now()
};

// DOM Elements
const form = document.getElementById('demoForm');
const togglePreventDefault = document.getElementById('togglePreventDefault');
const statusPill = document.getElementById('statusPill');
const virtualConsole = document.getElementById('virtualConsole');
const counterEl = document.getElementById('submitCounter');
const preventStatusEl = document.getElementById('preventStatus');
const domSpeedEl = document.getElementById('domSpeed');
const btnAutoFill = document.getElementById('btnAutoFill');
const btnClearForm = document.getElementById('btnClearForm');
const btnClearConsole = document.getElementById('btnClearConsole');
const btnCopyLog = document.getElementById('btnCopyLog');
const btnCopyCode = document.getElementById('btnCopyCode');
const toastEl = document.getElementById('toast');

// Dữ liệu mẫu phục vụ Auto-fill
const SAMPLE_DATA = [
    { name: "Nguyễn Văn An", email: "an.nguyen@lhu.edu.vn", phone: "0901234567", major: "cntt", message: "Em muốn đăng ký tham gia lớp thực hành JavaScript Web nâng cao." },
    { name: "Trần Thị Mai", email: "mai.tran@gmail.com", phone: "0912345678", major: "tkdh", message: "Đã hoàn thành bài tập Hoạt động 1 và kiểm tra console.log." },
    { name: "Lê Hoàng Phúc", email: "phuc.le@outlook.com", phone: "0987654321", major: "httt", message: "Thầy ơi cho em hỏi thêm về fetch() API gửi dữ liệu JSON lên Server!" },
    { name: "Phạm Hải Đăng", email: "dang.pham@yahoo.com", phone: "0977889900", major: "attt", message: "Kiểm tra kỹ thuật chặn tải lại trang: preventDefault() hoạt động hoàn hảo." }
];

let sampleIndex = 0;

// ====================================================================
// 1. KHỞI TẠO & LẮNG NGHE SỰ KIỆN FORM SUBMIT
// ====================================================================
document.addEventListener('DOMContentLoaded', () => {
    initEventListeners();
    logToVirtualConsole("system", "Hệ thống sẵn sàng. Vui lòng điền form hoặc bấm 'Điền mẫu nhanh' để thử nghiệm.");
    console.log("%c[Buổi 11] - Sẵn sàng thực hành Hoạt động 1: Stop the Page!", "color: #38bdf8; font-weight: bold; font-size: 14px;");
});

function initEventListeners() {
    // Lắng nghe sự kiện submit của Form
    form.addEventListener('submit', handleFormSubmit);

    // Toggle chuyển đổi trạng thái chặn reload
    if (togglePreventDefault) {
        togglePreventDefault.addEventListener('change', (e) => {
            AppState.isPreventDefaultActive = e.target.checked;
            updateStatusUI();
            
            if (AppState.isPreventDefaultActive) {
                showToast("Đã BẬT event.preventDefault() (Khuyên dùng)", "success");
                logToVirtualConsole("info", "⚙️ Chế độ: ĐÃ BẬT event.preventDefault() -> Không tải lại trang.");
            } else {
                showToast("CẢNH BÁO: Đã TẮT event.preventDefault() -> Trang sẽ reload khi submit!", "error");
                logToVirtualConsole("warn", "⚠️ Cảnh báo: TẮT preventDefault() -> Trình duyệt sẽ reload trang khi bấm Gửi.");
            }
        });
    }

    // Nút Auto-fill
    if (btnAutoFill) {
        btnAutoFill.addEventListener('click', autoFillSampleData);
    }

    // Nút Reset Form
    if (btnClearForm) {
        btnClearForm.addEventListener('click', () => {
            form.reset();
            showToast("Đã xóa sạch nội dung Form", "info");
            logToVirtualConsole("info", "🧹 Đã làm sạch các ô nhập liệu của Form.");
        });
    }

    // Nút Xóa Console
    if (btnClearConsole) {
        btnClearConsole.addEventListener('click', () => {
            virtualConsole.innerHTML = '';
            logToVirtualConsole("system", "Console ảo đã được làm sạch.");
            showToast("Đã xóa nhật ký console", "info");
        });
    }

    // Nút Copy Log
    if (btnCopyLog) {
        btnCopyLog.addEventListener('click', copyConsoleLogs);
    }

    // Nút Copy Code
    if (btnCopyCode) {
        btnCopyCode.addEventListener('click', copyCodeSnippet);
    }
}

// ====================================================================
// 2. HÀM XỬ LÝ SUBMIT (TRỌNG TÂM BÀI HỌC)
// ====================================================================
function handleFormSubmit(event) {
    const startTime = performance.now();

    // KIỂM TRA CHẾ ĐỘ PREVENT DEFAULT
    if (AppState.isPreventDefaultActive) {
        // -------------------------------------------------------------
        // CỐT LÕI: GỌI event.preventDefault() ĐỂ CHẶN TẢI LẠI TRANG
        // -------------------------------------------------------------
        event.preventDefault();
    } else {
        // NẾU TẮT: Cho phép trình duyệt thực hiện hành vi mặc định
        // Trang web sẽ nhấp nháy và tải lại toàn bộ, mất dữ liệu vừa nhập!
        alert("⚠️ Bạn đang ở chế độ TẮT event.preventDefault()!\nTrang web sẽ thực hiện hành vi mặc định: Tải lại toàn bộ trang (Reload) và mất dữ liệu vừa nhập!");
        return true; // Trình duyệt reload
    }

    // Trích xuất dữ liệu từ các trường nhập liệu
    const formData = {
        fullName: document.getElementById('fullName').value.trim(),
        email: document.getElementById('email').value.trim(),
        phone: document.getElementById('phone').value.trim() || "Chưa cung cấp",
        major: document.getElementById('major').value,
        message: document.getElementById('message').value.trim() || "(Trống)",
        timestamp: new Date().toLocaleTimeString('vi-VN')
    };

    const endTime = performance.now();
    const duration = (endTime - startTime).toFixed(2);

    // Cập nhật thống kê
    AppState.submitCount++;
    if (counterEl) counterEl.textContent = AppState.submitCount;
    if (domSpeedEl) domSpeedEl.textContent = `${duration} ms`;

    // 1. IN RA BẢNG ĐIỀU KHIỂN THẬT CỦA TRÌNH DUYỆT (F12 CONSOLE)
    console.group(`🛑 [Form Intercepted #${AppState.submitCount}] Lúc ${formData.timestamp}`);
    console.log("%c✔ Chặn tải lại trang thành công bằng event.preventDefault()!", "color: #10b981; font-weight: bold;");
    console.log("Họ và tên:", formData.fullName);
    console.log("Email:", formData.email);
    console.log("Số điện thoại:", formData.phone);
    console.log("Ngành học:", formData.major);
    console.log("Nội dung tin nhắn:", formData.message);
    console.log("Thời gian xử lý JS:", `${duration} ms`);
    console.table(formData);
    console.groupEnd();

    // 2. IN RA VIRTUAL CONSOLE TRÊN GIAO DIỆN
    logToVirtualConsole("success", `[Submit #${AppState.submitCount}] Đã chặn reload bằng event.preventDefault()!`, formData);

    // 3. THÔNG BÁO CHO NGƯỜI DÙNG
    showToast(`Gửi thành công! Dữ liệu đã in ra Console (F12).`, "success");
}

// ====================================================================
// 3. VIRTUAL CONSOLE LOGGER (MÔ PHỎNG DEVTOOLS CONSOLE)
// ====================================================================
function logToVirtualConsole(type, message, jsonData = null) {
    if (!virtualConsole) return;

    const timeString = new Date().toLocaleTimeString('vi-VN');
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;

    let jsonHtml = '';
    if (jsonData) {
        jsonHtml = `<div class="log-json">${escapeHtml(JSON.stringify(jsonData, null, 2))}</div>`;
    }

    entry.innerHTML = `
        <div>
            <span class="log-time">[${timeString}]</span>
            <span>${escapeHtml(message)}</span>
        </div>
        ${jsonHtml}
    `;

    virtualConsole.appendChild(entry);
    virtualConsole.scrollTop = virtualConsole.scrollHeight;
}

// ====================================================================
// 4. CÁC HÀM TIỆN ÍCH HỖ TRỢ
// ====================================================================
function autoFillSampleData() {
    const sample = SAMPLE_DATA[sampleIndex];
    sampleIndex = (sampleIndex + 1) % SAMPLE_DATA.length;

    document.getElementById('fullName').value = sample.name;
    document.getElementById('email').value = sample.email;
    document.getElementById('phone').value = sample.phone;
    document.getElementById('major').value = sample.major;
    document.getElementById('message').value = sample.message;

    showToast(`Đã tự động điền mẫu: ${sample.name}`, "info");
    logToVirtualConsole("info", `⚡ Đã nạp dữ liệu mẫu của học viên: ${sample.name}`);
}

function updateStatusUI() {
    if (AppState.isPreventDefaultActive) {
        statusPill.textContent = "preventDefault: BẬT";
        statusPill.className = "status-pill active";
        if (preventStatusEl) {
            preventStatusEl.textContent = "BẬT (Chặn Reload)";
            preventStatusEl.style.color = "var(--success)";
        }
    } else {
        statusPill.textContent = "preventDefault: TẮT";
        statusPill.className = "status-pill inactive";
        if (preventStatusEl) {
            preventStatusEl.textContent = "TẮT (Sẽ Reload)";
            preventStatusEl.style.color = "var(--danger)";
        }
    }
}

function showToast(message, type = "info") {
    if (!toastEl) return;
    toastEl.textContent = message;
    toastEl.className = `show ${type}`;

    clearTimeout(toastEl.hideTimeout);
    toastEl.hideTimeout = setTimeout(() => {
        toastEl.className = "";
    }, 3200);
}

function copyConsoleLogs() {
    const logsText = virtualConsole.innerText;
    navigator.clipboard.writeText(logsText).then(() => {
        showToast("Đã sao chép toàn bộ nhật ký Console vào Clipboard!", "success");
    }).catch(() => {
        showToast("Không thể sao chép, vui lòng thử lại.", "error");
    });
}

function copyCodeSnippet() {
    const codeSnippet = `const form = document.getElementById('contactForm');

form.addEventListener('submit', function (event) {
    // 1. Chặn hành vi mặc định (tải lại trang) của Form
    event.preventDefault();

    // 2. Thu thập dữ liệu từ các trường nhập liệu
    const name = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;

    // 3. In dữ liệu ra Console (F12) mà không làm mất trang
    console.log("Dữ liệu form:", { name, email });
});`;

    navigator.clipboard.writeText(codeSnippet).then(() => {
        showToast("Đã sao chép mã nguồn mẫu vào Clipboard!", "success");
    }).catch(() => {
        showToast("Lỗi sao chép mã nguồn.", "error");
    });
}

function escapeHtml(str) {
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
